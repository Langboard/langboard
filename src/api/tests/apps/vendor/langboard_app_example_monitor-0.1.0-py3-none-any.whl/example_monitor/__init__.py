"""Independent observations. Only public SDK/API, no implicit card ownership."""
from langboard_sdk import AppManager, AppRegistry, AppSignals, ConnectionCredentials

DECLARATION = {
    "schema_version": 2, "key": "example-monitor", "version": "1.0.0",
    "name": "Example Monitor", "description": "Independent issue observations.",
    "capabilities": ["signals.read", "signals.publish"], "resource_types": ["issue"],
    "signal_sources": ["example-monitor"],
    "signal_policy": {"version": 1, "event_types": ["issue.observed"], "resource_types": ["issue"],
        "outcome_states": {"open": "failed", "closed": "resolved"},
        "commit_mode": "empty", "time_basis": "observation"},
}

class Monitor:
    def __init__(self, owner_transport):
        self.owner = owner_transport

    async def register(self):
        return await AppRegistry(self.owner).approve(DECLARATION)

    async def connect(self, app_revision, organization_uid):
        return await self.owner.request("POST", "/settings/apps/registry/example-monitor/inbound-connections",
            json={"app_revision": app_revision, "organization_uid": organization_uid})

    async def consent(self, board_uid, app_revision):
        apps = AppManager(self.owner, board_uid)
        draft = await apps.prepare_consent("example-monitor", app_revision)
        return await apps.set_consent("example-monitor", app_revision, draft["uid"], draft["revision"],
                                     ["signals.read", "signals.publish"])

    async def select(self, board_uid, connection_uid, app_revision, binding, external_id):
        return await self.owner.request("PUT",
            f"/board/{board_uid}/settings/apps/example-monitor/inbound-connections/{connection_uid}/resources",
            json={"app_revision": app_revision, "binding_uid": binding["uid"],
                  "expected_revision": binding["revision"], "resource_type": "issue",
                  "external_resource_id": external_id})

    async def credential(self, connection_uid):
        return await ConnectionCredentials(self.owner).issue(connection_uid)

    @staticmethod
    async def observe(app_transport, credential, envelope):
        return await AppSignals(app_transport, credential).publish(envelope["board_uid"], envelope)
