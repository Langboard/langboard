"""Portable signal policy trust-boundary and renewed consent contracts."""

from copy import deepcopy
from unittest import IsolatedAsyncioTestCase, TestCase
from types import SimpleNamespace
from unittest.mock import AsyncMock
from .definition import validate_app_definition
from .governance import update_consent
from .signals import AppSignals, validate_signal_policy
from .rest import HttpTransport
from .client import MutationOutcomeUnknown
from .webhooks import verify_webhook


POLICY = {
    "version": 1, "event_types": ["issue.observed"], "resource_types": ["issue"],
    "outcome_states": {"open": "failed", "closed": "resolved"},
    "commit_mode": "empty", "time_basis": "observation",
}
APP = {
    "schema_version": 2, "key": "example-monitor", "version": "1.0.0", "name": "Example Monitor",
    "description": "Independent issue observations.", "resource_types": ["issue"],
    "capabilities": ["signals.read", "signals.publish", "panels.render"], "signal_policy": POLICY,
}


class SignalPolicyTests(TestCase):
    def test_resource_scope_change_requires_signal_reconsent(self):
        changed = {**APP, "version": "1.0.1", "resource_types": ["issue", "repository"]}
        decision = update_consent(APP, changed, APP["capabilities"])
        self.assertEqual(decision["retained"], {"panels.render"})
        self.assertEqual(decision["newly_requested"], {"signals.read", "signals.publish"})
        reordered = {**changed, "resource_types": ["repository", "issue"]}
        self.assertEqual(update_consent(changed, reordered, APP["capabilities"])["retained"], frozenset(APP["capabilities"]))

    def test_portable_finite_policy_and_copy(self):
        self.assertEqual(validate_app_definition(APP), APP)
        parsed = validate_signal_policy(POLICY, APP["resource_types"])
        parsed["event_types"].append("changed")
        self.assertEqual(POLICY["event_types"], ["issue.observed"])

    def test_invalid_policy_rejected_before_registration(self):
        changes = [
            {"version": True}, {"version": 2}, {"event_types": []}, {"event_types": ["*"]},
            {"event_types": ["same", "same"]}, {"event_types": ["event"] * 17},
            {"resource_types": ["foreign"]}, {"outcome_states": {}},
            {"outcome_states": {"open": "approved"}}, {"outcome_states": {"open": []}},
            {"commit_mode": "automatic"}, {"time_basis": "client_claim"}, {"extra": True},
        ]
        for change in changes:
            with self.subTest(change=change), self.assertRaises(ValueError):
                validate_app_definition({**APP, "signal_policy": {**POLICY, **change}})
        for value in (None, [], {}, {key: item for key, item in POLICY.items() if key != "time_basis"}):
            with self.subTest(value=value), self.assertRaises(ValueError):
                validate_app_definition({**APP, "signal_policy": value})
        with self.assertRaises(ValueError):
            validate_app_definition({**APP, "capabilities": ["signals.publish"]})
        with self.assertRaises(ValueError):
            validate_app_definition({key: value for key, value in APP.items() if key != "signal_policy"})

    def test_policy_update_requires_signal_reconsent_only(self):
        ordinary = {**APP, "version": "1.0.1"}
        self.assertEqual(update_consent(APP, ordinary, APP["capabilities"])["retained"], frozenset(APP["capabilities"]))
        changed = deepcopy(ordinary)
        changed["signal_policy"]["outcome_states"]["open"] = "unknown"
        decision = update_consent(APP, changed, APP["capabilities"])
        self.assertEqual(decision["retained"], {"panels.render"})
        self.assertEqual(decision["newly_requested"], {"signals.read", "signals.publish"})
        self.assertFalse(decision["trust_changed"])


class SignalPublisherTests(IsolatedAsyncioTestCase):
    async def test_invalid_success_receipt_is_unknown_and_never_retried(self):
        envelope = {"version": 1, "board_uid": "Board1", "resource_uid": "Resource1",
            "app_revision": "a" * 64, "binding_revision": "b" * 64, "event_id": "event-1",
            "event_type": "issue.observed", "occurred_at": "2026-10-11T00:00:00Z",
            "external_id": "55", "outcome": "open", "commit_sha": ""}
        for receipt in (None, {}, [], {"signal_uid": "../foreign", "duplicate": False},
                        {"signal_uid": "Signal1", "duplicate": "false"}, {"signal_uid": "Signal1"}):
            transport = SimpleNamespace(request=AsyncMock(return_value=receipt))
            with self.subTest(receipt=receipt), self.assertRaises(MutationOutcomeUnknown):
                await AppSignals(transport, "lbac_" + "a" * 43).publish("Board1", envelope)
            transport.request.assert_awaited_once()
        for duplicate in (False, True):
            receipt = {"signal_uid": "Signal1", "duplicate": duplicate}
            transport = SimpleNamespace(request=AsyncMock(return_value=receipt))
            self.assertEqual(await AppSignals(transport, "lbac_" + "a" * 43).publish("Board1", envelope), receipt)

    async def test_exact_bytes_signature_and_unknown_outcome_no_retry(self):
        import json
        token = "lbac_" + "a" * 43
        response = SimpleNamespace(status_code=200, json=lambda: {"signal_uid": "Signal1", "duplicate": False})
        session = SimpleNamespace(request=AsyncMock(return_value=response))
        publisher = AppSignals(HttpTransport(session), token)
        envelope = {"version": 1, "board_uid": "Board1", "resource_uid": "Resource1",
            "app_revision": "a" * 64, "binding_revision": "b" * 64, "event_id": "event-1",
            "event_type": "issue.observed", "occurred_at": "2026-10-11T00:00:00Z",
            "external_id": "55", "outcome": "open", "commit_sha": ""}
        self.assertEqual((await publisher.publish("Board1", envelope))["signal_uid"], "Signal1")
        args, wire = session.request.call_args
        self.assertEqual(args, ("POST", "/apps/v1/boards/Board1/signals"))
        self.assertEqual(json.loads(wire["content"]), envelope)
        self.assertEqual(wire["headers"]["Authorization"], "Bearer " + token)
        verify_webhook(wire["content"], wire["headers"], token)
        session.request.reset_mock()
        session.request.side_effect = TimeoutError("Unknown result")
        with self.assertRaises(MutationOutcomeUnknown):
            await publisher.publish("Board1", envelope)
        session.request.assert_awaited_once()
        session.request.reset_mock()
        with self.assertRaises(ValueError):
            await publisher.publish("Foreign", envelope)
        session.request.assert_not_awaited()
