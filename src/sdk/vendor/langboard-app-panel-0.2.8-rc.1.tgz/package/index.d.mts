import type { PanelSession } from "@langboard/app-protocol";
export type * from "@langboard/app-protocol";
export { PANEL_DESIGN_TOKENS } from "@langboard/app-protocol";
export { createPanelHost, PanelStateCache } from "@langboard/host-runtime";
export function connectPanel(options: {
    expectedHostOrigin: string;
    onShow?: (session: PanelSession) => void;
    onDispose?: () => void;
}): Promise<PanelSession>;
