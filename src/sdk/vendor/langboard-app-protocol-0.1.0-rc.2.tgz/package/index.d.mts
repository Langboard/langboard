export type JsonValue = null | boolean | number | string | JsonValue[] | { [key: string]: JsonValue };
export type PanelState = { [key: string]: JsonValue };
export interface PanelContext { project_uid: string; app_key: string; app_version: string; language: string; binding?: { uid: string; revision: string }; }
export const PANEL_DESIGN_TOKENS: readonly string[];
export const PANEL_PROTOCOL_VERSION: 1;
export const PANEL_LEGACY_OPERATIONS: readonly PanelOperation[];
export interface ResourceSelectionCandidate { resource_type: string; external_resource_id: string; label: string; }
export interface ResourceSelectionRequest { candidates: ResourceSelectionCandidate[]; }
export type PanelOperation = "signals.list" | "resources.list" | "resources.open" | "interactions.list" | "interactions.open" | "runtimes.open";
export const PANEL_OPERATIONS: readonly PanelOperation[];
export interface PanelAppearance { mode: "light" | "dark"; tokens: Record<string, string>; }
export interface PanelDesign extends PanelAppearance { resources?: { module_url: string; css_url: string }; }
export interface PanelHostDispose { (): void; updateDesign(design: PanelAppearance): void; }
export interface PanelSession {
    context: PanelContext;
    state: PanelState | null;
    design: PanelDesign | null;
    widgets: Promise<Record<string, unknown> | null>;
    signal: AbortSignal;
    readonly supportedOperations: readonly PanelOperation[] | null;
    request(operation: "resources.open", params: ResourceSelectionRequest): Promise<JsonValue>;
    request(operation: Exclude<PanelOperation, "resources.open">, params: JsonValue): Promise<JsonValue>;
    saveState(state: PanelState): void;
    close(): void;
    dispose(): void;
}
