"""Personal inbox access through the caller's authenticated user transport."""

from collections.abc import Sequence
from typing import Literal, NotRequired, TypedDict, cast

from .resources import _uid
from .rest import ApiTransport

NotificationInboxState = Literal["inbox", "later", "done"]
CardActivityMode = Literal["ignore", "comments", "comments_and_moves"]


class CardActivityPreference(TypedDict):
    mode: CardActivityMode
    reasons: list[Literal["creator", "assignee", "commenter", "mentioned", "direct"]]


class NotificationInboxThread(TypedDict):
    latest_event_uid: str
    latest_event_type: str
    latest_at: str
    project_uid: str | None
    card_uid: str | None
    card_title: str | None
    unread_events: int
    unread_mention: bool
    observed_unread_event_uids: list[str]
    observed_state_event_uids: list[str]


class NotificationInboxPage(TypedDict):
    threads: list[NotificationInboxThread]
    unread_count: int
    next_cursor: str | None


class NotificationInboxEvent(TypedDict):
    uid: str
    type: str
    created_at: str
    read_at: NotRequired[str | None]
    records: dict[str, dict[str, object]]
    message_vars: dict[str, object]
    notifier_user: NotRequired[dict[str, object]]
    notifier_bot: NotRequired[dict[str, object]]


class NotificationInboxMutation(TypedDict):
    updated_count: int


def _card_activity_path(project_uid: str, card_uid: str) -> str:
    return f"/notification/settings/project/{_uid(project_uid)}/card/{_uid(card_uid)}/activity"


def _state(value: NotificationInboxState) -> NotificationInboxState:
    if value not in ("inbox", "later", "done"):
        raise ValueError("Invalid inbox state")
    return value


def _event_uids(values: Sequence[str]) -> list[str]:
    if not isinstance(values, Sequence) or isinstance(values, (str, bytes)) or not values:
        raise ValueError("Pass a non-empty sequence of observed event UIDs")
    return list(dict.fromkeys(_uid(value) for value in values))


class NotificationInbox:
    """Read and update personal inbox events with a user-authenticated transport."""

    def __init__(self, transport: ApiTransport):
        self.transport = transport

    async def list_threads(
        self, *, state: NotificationInboxState = "inbox", unread_only: bool = False,
        limit: int = 20, cursor: str | None = None,
        project_uid: str | None = None, reason: str | None = None,
    ) -> NotificationInboxPage:
        """Read one page without changing read or disposition state."""
        if type(limit) is not int or not 1 <= limit <= 100:
            raise ValueError("Inbox page limit must be between 1 and 100")
        if type(unread_only) is not bool:
            raise ValueError("unread_only must be boolean")
        params = {"state": _state(state), "unread_only": unread_only, "limit": limit}
        if project_uid is not None:
            params["project_uid"] = _uid(project_uid)
        if reason is not None:
            if not isinstance(reason, str) or not reason:
                raise ValueError("Use a notification event type as the reason")
            params["reason"] = reason
        if cursor is not None:
            if not isinstance(cursor, str) or not 1 <= len(cursor) <= 80:
                raise ValueError("Use the cursor returned by the inbox")
            params["cursor"] = cursor
        return cast(NotificationInboxPage, await self.transport.request("GET", "/notifications/inbox", params=params))

    async def get_card_activity(self, project_uid: str, card_uid: str) -> CardActivityPreference:
        """Read your current card activity choice and participation reasons."""
        return cast(CardActivityPreference, await self.transport.request("GET", _card_activity_path(project_uid, card_uid)))

    async def set_card_activity(self, project_uid: str, card_uid: str, mode: CardActivityMode) -> CardActivityPreference:
        """Set your ordinary card activity preference. 'ignore' opts out of routine updates."""
        if mode not in ("ignore", "comments", "comments_and_moves"):
            raise ValueError("Invalid card activity mode")
        return cast(CardActivityPreference, await self.transport.request(
            "PUT", _card_activity_path(project_uid, card_uid), json={"mode": mode},
        ))

    async def list_activity(self, event_uids: Sequence[str]) -> list[NotificationInboxEvent]:
        """Read up to 30 observed events without changing their read state."""
        uids = _event_uids(event_uids)
        if len(uids) > 30:
            raise ValueError("Pass at most 30 activity event UIDs")
        response = await self.transport.request("GET", "/notifications/inbox/events", params={"event_uids": uids})
        return cast(list[NotificationInboxEvent], response["notifications"])

    async def mark_read(self, event_uids: Sequence[str]) -> NotificationInboxMutation:
        """Mark only the event UIDs observed in the retrieved inbox page."""
        return cast(NotificationInboxMutation, await self.transport.request(
            "PUT", "/notifications/inbox/read-events", json={"event_uids": _event_uids(event_uids)},
        ))

    async def set_state(
        self, event_uids: Sequence[str], *, expected_state: NotificationInboxState, state: NotificationInboxState,
    ) -> NotificationInboxMutation:
        """Update the disposition of observed events with the expected state."""
        return cast(NotificationInboxMutation, await self.transport.request(
            "PUT", "/notifications/inbox/state",
            json={"event_uids": _event_uids(event_uids), "expected_state": _state(expected_state), "state": _state(state)},
        ))
