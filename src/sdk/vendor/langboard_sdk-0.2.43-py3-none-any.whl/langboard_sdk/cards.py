"""App-owned card creation and content. Receipts do not authorize execution."""

import re
from hashlib import sha256
from json import dumps
from typing import Literal, TypedDict, cast
from .client import MutationOutcomeUnknown
from .resources import _uid
from .rest import ApiTransport


class AppCardCreationReceipt(TypedDict):
    card_uid: str
    receipt_uid: str
    created: bool
    effects_state: Literal["pending", "dispatched", "failed"]


def _creation_body(resource_uid, external_id, title, description, card_type, presentation):
    _uid(resource_uid)
    for value, maximum in ((external_id, 200), (title, 200), (description, 100000)):
        if not isinstance(value, str) or len(value) > maximum:
            raise ValueError("Invalid app card text")
    if not external_id or not title:
        raise ValueError("External identity and title are required")
    if card_type is not None and (not isinstance(card_type, str) or not re.fullmatch(r"[a-z][a-z0-9_-]{0,63}", card_type)):
        raise ValueError("Invalid app card type")
    if presentation is not None and not isinstance(presentation, dict):
        raise ValueError("App card presentation must be an object")
    body: dict = {"resource_uid": resource_uid, "external_id": external_id, "title": title, "description": description}
    if card_type is not None:
        body["card_type"] = card_type
    if presentation is not None:
        body["presentation"] = presentation
    return body


class AppCards:
    def __init__(self, transport: ApiTransport):
        self.transport = transport

    async def create(self, board_uid: str, *, resource_uid: str, external_id: str, title: str,
                     description: str = "", card_type: str | None = None,
                     presentation: dict | None = None) -> AppCardCreationReceipt:
        """Create through app authority once; preserve source identity on an unknown outcome.

        The host owns Backlog selection, current authority and identical replay.
        This method never retries. Reconcile a lost response with read_creation_receipt
        using the same source identity and original creation payload.
        """
        board_uid = _uid(board_uid)
        body = _creation_body(resource_uid, external_id, title, description, card_type, presentation)
        result = await self.transport.request("POST", f"/apps/v1/boards/{board_uid}/cards", json=body)
        try:
            _uid(result["card_uid"])
            _uid(result["receipt_uid"])
            if type(result["created"]) is not bool or result["effects_state"] not in ("pending", "dispatched", "failed"):
                raise ValueError("Invalid creation receipt")
        except (KeyError, TypeError, ValueError):
            raise MutationOutcomeUnknown(
                "App card creation receipt unavailable; retain the original source identity and payload before reconciliation"
            ) from None
        return cast(AppCardCreationReceipt, result)

    async def read_creation_receipt(self, board_uid: str, *, resource_uid: str, external_id: str,
                                    title: str, description: str = "", card_type: str | None = None,
                                    presentation: dict | None = None) -> dict:
        """Read one source receipt using the exact original create arguments; never POST.

        A missing receipt is a point-in-time observation, not permission to retry.
        HTTP 403/409 and transport errors propagate; none means a missing receipt.
        """
        board_uid = _uid(board_uid)
        _creation_body(resource_uid, external_id, title, description, card_type, presentation)
        fingerprint = sha256(dumps(
            [title, description, presentation, card_type] if card_type is not None
            else [title, description, presentation], sort_keys=True, ensure_ascii=False,
        ).encode()).hexdigest()
        result = await self.transport.request("GET", f"/apps/v1/boards/{board_uid}/card-creation-receipt", params={
            "resource_uid": resource_uid, "external_id": external_id, "payload_fingerprint": fingerprint,
        })
        try:
            if type(result["found"]) is not bool:
                raise ValueError()
            if result["found"]:
                receipt = result["receipt"]
                _uid(receipt["card_uid"])
                _uid(receipt["receipt_uid"])
                if (receipt["created"] is not False
                        or receipt["effects_state"] not in ("pending", "dispatched", "failed")
                        or result["payload_fingerprint"] != fingerprint):
                    raise ValueError()
            elif set(result) != {"found"}:
                raise ValueError()
        except (KeyError, TypeError, ValueError):
            raise RuntimeError("App card creation lookup returned an invalid receipt; reconciliation remains unknown") from None
        return result

    async def read(self, board_uid: str, card_uid: str, *, offset: int = 0, limit: int = 16000) -> dict:
        board_uid, card_uid = _uid(board_uid), _uid(card_uid)
        if type(offset) is not int or offset < 0 or type(limit) is not int or not 1 <= limit <= 16000:
            raise ValueError("Invalid card content window")
        return await self.transport.request("GET", f"/apps/v1/boards/{board_uid}/cards/{card_uid}",
                                            params={"offset": offset, "limit": limit})

    async def read_archive_outcome(self, board_uid: str, archive_uid: str) -> dict:
        """Read a current owning-app receipt; no provider mutation or delivery retry."""
        board_uid, archive_uid = _uid(board_uid), _uid(archive_uid)
        return await self.transport.request("GET", f"/apps/v1/boards/{board_uid}/archives/{archive_uid}")

    async def report_archive_outcome(self, board_uid: str, archive_uid: str, *, expected_revision: int,
                                     state: str, external_state: str | None, readback_confirmed: bool) -> dict:
        """Report a provider outcome using a connection credential, without executing or retrying it.

        Keep the original revision and outcome on an ambiguous retry. Successful
        transport is not proof of an external change; applied states require readback.
        """
        board_uid, archive_uid = _uid(board_uid), _uid(archive_uid)
        if type(expected_revision) is not int or expected_revision < 0:
            raise ValueError("A nonnegative outcome revision is required")
        if state not in ("applied", "already_applied", "failed", "blocked", "unknown") or type(readback_confirmed) is not bool:
            raise ValueError("Invalid archive outcome")
        if external_state is not None and (not isinstance(external_state, str) or not external_state.strip() or len(external_state) > 64):
            raise ValueError("Invalid provider state")
        if state in ("applied", "already_applied") and (not readback_confirmed or not external_state):
            raise ValueError("Applied outcomes require provider state readback")
        return await self.transport.request("POST", f"/apps/v1/boards/{board_uid}/archives/{archive_uid}/outcome", json={
            "expected_revision": expected_revision,
            "outcome": {"state": state, "external_state": external_state, "readback_confirmed": readback_confirmed},
        })
