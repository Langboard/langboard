"""Native transfer transport. Authentication and business ownership stay with callers."""

import json
import re
from uuid import UUID
from typing import BinaryIO
from .client import MutationOutcomeUnknown
from .resources import _uid
from .rest import ApiTransport, TransferTransport
from .webhooks import InvalidWebhook, verify_webhook


TRANSFER_EVENT = "io.langboard.app.transfer.requested.v1"


def _app(value):
    if not isinstance(value, str) or not re.fullmatch(r"[a-z][a-z0-9_-]{0,31}", value):
        raise ValueError("A native app key is required")
    return value


def _uuid(value):
    if not isinstance(value, str) or str(UUID(value)) != value:
        raise ValueError("A canonical client request UUID is required")
    return value


def _number(value):
    if type(value) is not int or value < 0:
        raise ValueError("A nonnegative revision or offset is required")
    return value


def _hash(value):
    if not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{64}", value):
        raise ValueError("An immutable SHA256 digest is required")
    return value


def _intent(value):
    fields = {"card_revision", "resource_uid", "attachment_uid", "attachment_revision", "content_sha256"}
    if not isinstance(value, dict) or set(value) != fields:
        raise ValueError("Exact native transfer intent required")
    _number(value["card_revision"])
    _uid(value["resource_uid"])
    if value["attachment_uid"] is None:
        if value["attachment_revision"] is not None or value["content_sha256"] is not None:
            raise ValueError("Card transfers cannot include attachment metadata")
    else:
        _uid(value["attachment_uid"])
        _hash(value["attachment_revision"])
        _hash(value["content_sha256"])
    return dict(value)


def _view(result, **expected):
    if not isinstance(result, dict):
        raise ValueError("Invalid transfer response")
    for field in ("transfer_uid", "board_uid", "card_uid", "connection_uid"):
        _uid(result[field])
    _app(result["app_key"])
    _uuid(result["client_request_id"])
    _intent(result["intent"])
    _uid(result["delivery"]["event_uid"])
    _number(result["receipt"]["revision"])
    _number(result["receipt"]["retry_revision"])
    if result.get("started") is not False or any(result.get(key) != value for key, value in expected.items()):
        raise ValueError("Transfer response scope mismatch")
    return result


def _read(result, **expected):
    try:
        return _view(result, **expected)
    except (KeyError, TypeError, ValueError):
        raise RuntimeError("Transfer read response unavailable or scope mismatch") from None


def _receipt(result, *, revision=None, retry_revision=None, **expected):
    try:
        _view(result, **expected)
        if (type(result.get("changed")) is not bool
            or (revision is not None and result["receipt"]["revision"] != revision)
            or (retry_revision is not None and result["receipt"]["retry_revision"] != retry_revision)):
            raise ValueError("Receipt mismatch")
    except (KeyError, TypeError, ValueError):
        raise MutationOutcomeUnknown("Transfer receipt unavailable; reconcile original request and revision") from None
    return result


def parse_transfer_event(body: bytes, headers, secret: str, *, now: int | None = None) -> dict:
    """Verify exact bytes first. Caller must atomically deduplicate event_uid in a durable inbox."""
    verify_webhook(body, headers, secret, now=now)
    try:
        event = json.loads(body)
        if not isinstance(event, dict) or type(event.get("schema_version")) is not int or event["schema_version"] != 1:
            raise ValueError("Unsupported event")
        if event.get("event_type") != TRANSFER_EVENT or event.get("started") is not False:
            raise ValueError("Invalid transfer event")
        for field in ("event_uid", "request_uid", "board_uid", "card_uid", "connection_uid"):
            _uid(event[field])
        _app(event["app_key"])
        _intent({key: event[key] for key in ("card_revision", "resource_uid", "attachment_uid", "attachment_revision", "content_sha256")})
        destination = event["destination"]
        if not isinstance(destination, dict) or set(destination) != {"destination_uid", "revision"}:
            raise ValueError("Invalid destination fence")
        _uid(destination["destination_uid"])
        _number(destination["revision"])
        if destination["revision"] < 1:
            raise ValueError("Invalid destination revision")
    except (KeyError, TypeError, ValueError):
        raise InvalidWebhook("Invalid signed transfer event") from None
    return event


class AppTransfers:
    """Use only an authenticated app connection transport. No automatic report retry."""

    def __init__(self, transport: TransferTransport):
        self.transport = transport

    @staticmethod
    def _path(board_uid, transfer_uid):
        return f"/apps/v1/boards/{_uid(board_uid)}/transfers/{_uid(transfer_uid)}"

    async def read(self, board_uid: str, transfer_uid: str, *, offset: int = 0, limit: int = 16000) -> dict:
        if type(limit) is not int or not 1 <= limit <= 16000:
            raise ValueError("Content limit must be 1 to 16000")
        result = await self.transport.request("GET", self._path(board_uid, transfer_uid),
                                              params={"offset": _number(offset), "limit": limit})
        return _read(result, board_uid=board_uid, transfer_uid=transfer_uid)

    async def report(self, board_uid: str, transfer_uid: str, *, expected_revision: int,
                     acknowledgment: str = "received", provider_outcome: str | None = None) -> dict:
        path = self._path(board_uid, transfer_uid)
        _number(expected_revision)
        if acknowledgment != "received" or provider_outcome not in (None, "unknown", "failed", "delivered", "already_delivered"):
            raise ValueError("Invalid transfer report")
        result = await self.transport.request("POST", f"{path}/receipt", json={
            "expected_revision": expected_revision, "acknowledgment": acknowledgment, "provider_outcome": provider_outcome})
        result = _receipt(result, board_uid=board_uid, transfer_uid=transfer_uid, revision=expected_revision + 1)
        if result["receipt"].get("acknowledgment") != acknowledgment or result["receipt"].get("provider_outcome") != provider_outcome:
            raise MutationOutcomeUnknown("Report receipt mismatch; read original transfer before retrying")
        return result

    async def attachment(self, board_uid: str, transfer_uid: str, *, content_sha256: str, max_bytes: int) -> BinaryIO:
        """Return a validated seekable temporary file; caller must close it after use.

        No file is returned before EOF, byte bound and both hashes are verified.
        The transport must provide download using its caller-owned authenticated session.
        """
        return await self.transport.download(self._path(board_uid, transfer_uid) + "/attachment",
                                             content_sha256=_hash(content_sha256), max_bytes=max_bytes)


class TransferOutbox:
    """Use only a human authenticated management transport. Review never grants consent."""

    def __init__(self, transport: ApiTransport):
        self.transport = transport

    @staticmethod
    def _request(board_uid, client_request_id):
        return f"/board/{_uid(board_uid)}/app-transfers/by-request/{_uuid(client_request_id)}"

    async def review(self, board_uid: str, card_uid: str, app_key: str, *, attachment_uid=None, after_uid=None) -> dict:
        params = {}
        if attachment_uid is not None:
            params["attachment_uid"] = _uid(attachment_uid)
        if after_uid is not None:
            params["after"] = _uid(after_uid)
        return await self.transport.request("GET", f"/board/{_uid(board_uid)}/card/{_uid(card_uid)}/apps/{_app(app_key)}/transfer-review", params=params)

    async def create(self, board_uid: str, card_uid: str, app_key: str, *, client_request_id: str,
                     connection_uid: str, intent: dict, expected_authority: dict) -> dict:
        """Persist the original UUID and exact reviewed input before calling. Reconcile unknown results."""
        if not isinstance(expected_authority, dict) or not expected_authority:
            raise ValueError("An unchanged reviewed authority snapshot is required")
        intent = _intent(intent)
        result = await self.transport.request("POST", f"/board/{_uid(board_uid)}/card/{_uid(card_uid)}/apps/{_app(app_key)}/transfers", json={
            "client_request_id": _uuid(client_request_id), "connection_uid": _uid(connection_uid),
            "intent": _intent(intent), "expected_authority": dict(expected_authority)})
        return _receipt(result, board_uid=board_uid, card_uid=card_uid, app_key=app_key,
                        connection_uid=connection_uid, intent=intent, client_request_id=client_request_id)

    async def list(self, board_uid: str, app_key: str, *, limit: int = 20, after_uid=None) -> dict:
        if type(limit) is not int or not 1 <= limit <= 50:
            raise ValueError("Outbox limit must be 1 to 50")
        params = {"limit": limit}
        if after_uid is not None:
            params["after"] = _uid(after_uid)
        return await self.transport.request("GET", f"/board/{_uid(board_uid)}/apps/{_app(app_key)}/transfers", params=params)

    async def read(self, board_uid: str, client_request_id: str) -> dict:
        result = await self.transport.request("GET", self._request(board_uid, client_request_id))
        if isinstance(result, dict) and set(result) == {"found"} and result["found"] is False:
            return {"found": False}
        if not isinstance(result, dict) or result.get("found") is not True:
            raise RuntimeError("Sender transfer read response unavailable")
        return _read(result, board_uid=board_uid, client_request_id=client_request_id)

    async def retry(self, board_uid: str, client_request_id: str, *, expected_retry_revision: int) -> dict:
        """Explicit exhausted-delivery retry only; unknown outcome requires original-request read."""
        path = self._request(board_uid, client_request_id)
        result = await self.transport.request("POST", path + "/retry", json={"expected_retry_revision": _number(expected_retry_revision)})
        return _receipt(result, board_uid=board_uid, client_request_id=client_request_id, retry_revision=expected_retry_revision + 1)
