"""REST transport using a caller-owned authenticated async HTTP session."""

from typing import Any, BinaryIO, Protocol
from .client import MutationOutcomeUnknown, _diagnostic_token


class ApiTransport(Protocol):
    async def request(self, method: str, path: str, *, params: dict | None = None, json: dict | None = None,
                      content: bytes | None = None, headers: dict | None = None) -> dict:
        """One native API request; ambiguous mutations must never be retried."""
        ...


class TransferTransport(ApiTransport, Protocol):
    async def download(self, path: str, *, content_sha256: str, max_bytes: int) -> BinaryIO:
        """Return validated seekable staging; caller closes it. No retries or redirects."""
        ...


class NativeApiError(RuntimeError):
    def __init__(self, status_code: int, method: str, path: str, result: Any):
        self.status_code, self.method, self.path, self.result = status_code, method, path, result
        self.code = _diagnostic_token(result, "code")
        self.request_id = _diagnostic_token(result, "request_id")
        super().__init__(f"Langboard API returned HTTP {status_code}")


class HttpTransport:
    """Accept an authenticated httpx-compatible AsyncClient; no auth or lifecycle ownership.

    Configure its base_url to the native API origin, timeout and credentials.
    It must have redirects and retries disabled. The SDK never fetches credentials.
    """

    def __init__(self, session: Any):
        if getattr(session, "follow_redirects", False):
            raise ValueError("Management sessions must not follow redirects")
        self.session = session

    async def request(self, method: str, path: str, *, params: dict | None = None, json: dict | None = None,
                      content: bytes | None = None, headers: dict | None = None) -> dict:
        if content is not None and json is not None:
            raise ValueError("Choose JSON or exact signed bytes")
        wire = {}
        if content is not None:
            wire["content"] = content
        if headers is not None:
            wire["headers"] = headers
        mutation = method.upper() not in {"GET", "HEAD", "OPTIONS"}
        try:
            response = await self.session.request(method, path, params=params, json=json, **wire)
        except Exception as error:
            if mutation:
                raise MutationOutcomeUnknown(
                    "API mutation response unavailable; read current state before retrying"
                ) from error
            raise
        try:
            result = response.json()
        except Exception:
            result = None
        if not 200 <= response.status_code < 300:
            error = NativeApiError(response.status_code, method, path, result)
            if mutation and response.status_code >= 500:
                raise MutationOutcomeUnknown(
                    "API mutation returned a server error; read current state before retrying"
                ) from error
            raise error
        if not isinstance(result, dict):
            if mutation:
                raise MutationOutcomeUnknown("API mutation receipt unavailable; read current state before retrying")
            raise RuntimeError("Langboard API returned an invalid response")
        return result

    async def download(self, path: str, *, content_sha256: str, max_bytes: int) -> BinaryIO:
        """Stage one authenticated binary read; return only a fully validated file.

        Caller owns the returned file. Every unsuccessful or cancelled read closes
        staging. Configure the session without retries; redirects are disabled per call.
        """
        import re
        import tempfile
        from hashlib import sha256
        from hmac import compare_digest

        if not isinstance(content_sha256, str) or not re.fullmatch(r"[0-9a-f]{64}", content_sha256):
            raise ValueError("Expected SHA256 is required")
        if type(max_bytes) is not int or max_bytes < 1:
            raise ValueError("A positive caller byte limit is required")
        if not isinstance(path, str) or not re.fullmatch(r"/apps/v1/boards/[A-Za-z0-9]{11}/transfers/[A-Za-z0-9]{11}/attachment", path):
            raise ValueError("A native transfer attachment path is required")
        target = tempfile.SpooledTemporaryFile(max_size=min(max_bytes, 1024 * 1024), mode="w+b")
        try:
            async with self.session.stream("GET", path, follow_redirects=False) as response:
                if not 200 <= response.status_code < 300:
                    # Native diagnostic JSON is bounded independently of file bytes.
                    import json
                    diagnostic = bytearray()
                    async for chunk in response.aiter_bytes(chunk_size=4096):
                        if len(chunk) > 4096 or len(diagnostic) + len(chunk) > 16384:
                            break
                        diagnostic.extend(chunk)
                    try:
                        result = json.loads(diagnostic)
                    except (ValueError, UnicodeError):
                        result = None
                    error = NativeApiError(response.status_code, "GET", path, result)
                    if error.request_id is None:
                        error.request_id = _diagnostic_token({"request_id": response.headers.get("x-request-id")}, "request_id")
                    raise error
                digest = response.headers.get("x-content-sha256")
                if digest != content_sha256 or response.headers.get("content-type", "").split(";")[0].strip().lower() != "application/octet-stream":
                    raise ValueError("Attachment integrity metadata mismatch")
                encoding = response.headers.get("content-encoding", "identity")
                if encoding.lower() != "identity":
                    raise ValueError("Encoded attachment streams are unsupported")
                total = 0
                checksum = sha256()
                async for chunk in response.aiter_bytes(chunk_size=64 * 1024):
                    if not isinstance(chunk, bytes) or len(chunk) > 64 * 1024:
                        raise ValueError("Attachment transport exceeded chunk bound")
                    total += len(chunk)
                    if total > max_bytes:
                        raise ValueError("Attachment exceeds caller byte limit")
                    target.write(chunk)
                    checksum.update(chunk)
                if not compare_digest(checksum.hexdigest(), content_sha256):
                    raise ValueError("Attachment SHA256 mismatch")
                length = response.headers.get("content-length")
                if length is not None and (not length.isascii() or not length.isdigit() or int(length) != total):
                    raise ValueError("Attachment length mismatch")
            target.seek(0)
            return target
        except BaseException:
            target.close()
            raise
