"""Portable signal policy trust-boundary and renewed consent contracts."""

from copy import deepcopy
from unittest import TestCase
from .definition import validate_app_definition
from .governance import update_consent
from .signals import validate_signal_policy


POLICY = {
    "version": 1, "event_types": ["issue.observed"], "resource_types": ["issue"],
    "outcome_states": {"open": "failed", "closed": "resolved"},
    "commit_mode": "empty", "time_basis": "observation",
}
APP = {
    "schema_version": 2, "key": "example-monitor", "version": "1.0.0", "name": "Example Monitor",
    "description": "Independent issue observations.", "resource_types": ["issue"],
    "capabilities": ["signals.read", "signals.publish", "panels.render"], "signal_policy": POLICY,
}


class SignalPolicyTests(TestCase):
    def test_portable_finite_policy_and_copy(self):
        self.assertEqual(validate_app_definition(APP), APP)
        parsed = validate_signal_policy(POLICY, APP["resource_types"])
        parsed["event_types"].append("changed")
        self.assertEqual(POLICY["event_types"], ["issue.observed"])

    def test_invalid_policy_rejected_before_registration(self):
        changes = [
            {"version": True}, {"version": 2}, {"event_types": []}, {"event_types": ["*"]},
            {"event_types": ["same", "same"]}, {"event_types": ["event"] * 17},
            {"resource_types": ["foreign"]}, {"outcome_states": {}},
            {"outcome_states": {"open": "approved"}}, {"outcome_states": {"open": []}},
            {"commit_mode": "automatic"}, {"time_basis": "client_claim"}, {"extra": True},
        ]
        for change in changes:
            with self.subTest(change=change), self.assertRaises(ValueError):
                validate_app_definition({**APP, "signal_policy": {**POLICY, **change}})
        for value in (None, [], {}, {key: item for key, item in POLICY.items() if key != "time_basis"}):
            with self.subTest(value=value), self.assertRaises(ValueError):
                validate_app_definition({**APP, "signal_policy": value})
        with self.assertRaises(ValueError):
            validate_app_definition({**APP, "capabilities": ["signals.publish"]})
        with self.assertRaises(ValueError):
            validate_app_definition({key: value for key, value in APP.items() if key != "signal_policy"})

    def test_policy_update_requires_signal_reconsent_only(self):
        ordinary = {**APP, "version": "1.0.1"}
        self.assertEqual(update_consent(APP, ordinary, APP["capabilities"])["retained"], frozenset(APP["capabilities"]))
        changed = deepcopy(ordinary)
        changed["signal_policy"]["outcome_states"]["open"] = "unknown"
        decision = update_consent(APP, changed, APP["capabilities"])
        self.assertEqual(decision["retained"], {"panels.render"})
        self.assertEqual(decision["newly_requested"], {"signals.read", "signals.publish"})
        self.assertFalse(decision["trust_changed"])
