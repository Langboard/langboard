"""Finite external signal semantics. A declaration is never an ingestion grant."""

import re
from copy import deepcopy


def validate_signal_policy(value, resource_types):
    fields = {"version", "event_types", "resource_types", "outcome_states", "commit_mode", "time_basis"}
    if not isinstance(value, dict) or set(value) != fields or type(value["version"]) is not int or value["version"] != 1:
        raise ValueError("Invalid signal policy schema")
    for field, pattern in (("event_types", r"[a-z][a-z0-9_.-]{0,63}"), ("resource_types", r"[a-z][a-z0-9_-]{0,63}")):
        items = value[field]
        if (not isinstance(items, list) or not 1 <= len(items) <= 16
            or any(not isinstance(item, str) or not re.fullmatch(pattern, item) for item in items)
            or len(set(items)) != len(items)):
            raise ValueError("Signal policy needs finite unique event/resource keys")
    if set(value["resource_types"]) - set(resource_types):
        raise ValueError("Signal resources must be declared by the app")
    outcomes = value["outcome_states"]
    if (not isinstance(outcomes, dict) or not 1 <= len(outcomes) <= 16
        or any(not isinstance(key, str) or not re.fullmatch(r"[a-z][a-z0-9_-]{0,63}", key)
               or not isinstance(state, str) or state not in {"passed", "failed", "resolved", "ignored", "queued", "running", "cancelled", "unknown"}
               for key, state in outcomes.items())):
        raise ValueError("Invalid finite signal outcome mapping")
    if value["commit_mode"] not in ("required", "empty", "optional") or value["time_basis"] not in ("provider_occurrence", "observation"):
        raise ValueError("Invalid signal commit/time semantics")
    return deepcopy(value)
