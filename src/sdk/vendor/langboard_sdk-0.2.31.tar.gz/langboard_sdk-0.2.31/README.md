# Langboard Python SDK

Start with the [installation, authentication and management guide](GUIDE.md).
`AppRegistry` manages instance-approved external app definitions and revisions.
`AppManager` manages board App catalogs, workflow drafts, panel consent and binding disablement.
`ConnectionManager` handles native instance onboarding and resource selection.
`GlitchTipManager` and `DokployManager` add provider read consent, signal refresh,
and Dokploy webhook management through the native API.
`LangboardClient` handles native MCP work commands. See the guide's support table
for routes that are not yet covered; this is not a full administrative API SDK.

A standalone package with no runtime dependencies on Langboard server internals,
ChatGPT, a company identity provider, or a database. Native Langboard remains the
owner of validation, current authorization, transactions, and durable receipts.

```python
from fastmcp import Client  # Your chosen MCP implementation; not an SDK dependency.
from langboard_sdk import LangboardClient, McpTransport

async with Client("https://your-board.example/api/mcp/oauth/stream", auth="oauth") as session:
    board = LangboardClient(McpTransport(session))
    preview = await board.preview_work_plan(plan)
    # Display/review the plan and obtain the user's intended authorization.
    result = await board.apply_work_plan(plan, preview["revision"], stable_request_id)
```

Any transport with `async call(name, arguments, *, mutation=False)` can be used.
A host adapter may provide token exchange or confirmation, but cannot supply a
principal override or bypass the server's stored roles. SDK calls never combine
multiple mutation commands, mint a revision, or retry an ambiguous write.

Keep the exact reviewed plan, returned revision, and request ID together. A lost
response requires reading current state; only the same request may be replayed.
A changed plan requires a new preview. Work-plan handling supports the existing
native server contract; this initial package does not claim to cover every API.
External app registration is available through `AppRegistry`; it does not install
server code. [Support boundaries](GUIDE.md#support-and-verification-boundaries) distinguish
registry, panel, automation and outbox acceptance.

Build independently from this repository root: `uv build --out-dir dist packages/python`.

## Local distribution

This repository prepares `langboard-sdk` 0.2.29 as a standalone Python wheel and
source archive. It does not publish to PyPI or a company registry, and does not
configure hosted CI. A reviewed build can be installed without the core checkout:

```sh
python -m pip install --no-index --no-deps dist/langboard_sdk-0.2.29-py3-none-any.whl
```

Retain and pin the reviewed artifact digest in your chosen package repository or
build input. Host compatibility is limited to the native routes and commands
documented in [GUIDE.md](GUIDE.md); no all-version compatibility claim is made.
The SDK repository is the source authority after extraction. A host must consume
the same reviewed SDK version rather than maintain a parallel edited copy.
Authentication, provider integration and deployment acceptance remain separate.

## MCP errors and uncertain writes

`McpTransport` accepts an already connected FastMCP-style client whose
`call_tool(..., raise_on_error=False)` returns `is_error`, `structured_content`,
and content blocks. It does not open or close the client or manage credentials.
A server error raises `NativeCommandError`; its `command` and original `result`
retain structured details and content for the caller. The exception message does
not automatically print the returned payload. An error response is not proof
that a mutation had no effects: inspect current state before replaying it.

A client/protocol exception or missing structured receipt for a mutation raises
`MutationOutcomeUnknown`, preserving the original exception as its cause.
Read failures propagate unchanged. Neither path retries the command. Cancellation
and other Python `BaseException` signals remain under caller control.


## Card display types and app origins

After authorized native card creation, call `set_card_presentation(project_uid,
card_uid, presentation)` to attach optional display metadata. The existing native
`save_public_card_metadata` command owns permissions, storage and socket updates.
This call is separate from creation: on failure the card still exists. Read its
metadata before retrying an unknown outcome. No automatic write replay.

```python
await board.set_card_presentation(project_uid, card_uid, {
    "version": 1,
    "key": "app.github.issue",
    "axis": "origin",  # "type" is also supported; no policy axes
    "name": "GitHub issue",  # English fallback, plain text
    "description": "App-reported origin. Workflow and reviewer approval remain separate.",
    "icon": "🔗",  # optional plain text, never remote HTML or SVG
    "translations": {
        "ko-KR": {"name": "깃허브 이슈", "description": "앱에서 제공한 출처입니다. 완료·승인 상태와 별개입니다."},
    },
})
```

The common UI renderer uses exact locale, language, then English fallback.
The server limits keys to `app.<app-key>.<kind-key>`, allows only `type`/`origin`,
and rejects authorization/status fields. App-reported origins are self-declared,
not verified provider identity. Native visibility always renders independently.
`source_type`/`source_uid` remain linked-resource references; do not overwrite them
for work cards originating from apps. Lifecycle, workflow, material kind, access
and reviewer evidence retain their existing authoritative models.

Contract limits: version 1; name 80 characters; description 1000; icon 32;
at most 16 BCP-47-style locale entries; encoded payload 8192 characters.
Unknown/malformed metadata is hidden in the UI and cannot affect policy.


### Atomic app card creation

To create a card and its display trait together, include `presentation` in a
`new_cards` entry of the existing native work plan. The reviewed revision binds
the presentation too. The server stores it in the same transaction as the card,
relationships, checklists, and durable receipt; a failed metadata write rolls
back the plan. Public metadata events are emitted only after commit. Replaying
the identical request returns the receipt without duplicating cards or events.

```python
plan = {
    "project_uid": project_uid,
    "anchor_card_uid": anchor_card_uid,
    "new_cards": [{
        "client_ref": "new:external-issue",
        "title": "Investigate external issue",
        "presentation": {
            "version": 1,
            "key": "app.glitchtip.issue",
            "axis": "origin",
            "name": "GlitchTip issue",
            "description": "App-reported origin. Resolution is separate from approval.",
            "icon": "🔗",
        },
    }],
}
preview = await board.preview_work_plan(plan)
# Use the reviewed plan, returned revision, and stable request ID together.
result = await board.apply_work_plan(plan, preview["revision"], stable_request_id)
```

This uses the selected anchor's board/column and native creation permissions.
It does not connect to a provider, verify its identity, or enable automatic card
creation. Existing cards can continue to use `set_card_presentation` separately.
When `presentation` is absent, old work-plan serialized payloads stay unchanged.

## Authorized resource context

`await board.get_connection_context(project_uid, card_uid=None, cursor=None)`
reads one bounded native resource page. One board App binding can select several
resources from several connections; one external resource can be selected by
several boards through separate board-owned bindings. Keep both connection and
resource identities, plus each returned revision. Follow `resources.next_cursor`
explicitly when needed. The SDK never retrieves credentials, grants access,
registers provider code, or automatically executes a workflow transition.

Workflow mapping uses stable stage keys and current authorized column identities,
not translated names. Several columns may share a stage: the user must choose an
explicit destination. Missing, inactive or ambiguous stages disable transitions;
metadata reads remain independent. New adapters select built-in workflow types in their
host-installed manifest; app-specific stage definitions are not supported. The current SDK exposes resource discovery, not a full
provider onboarding/registration API.


## Built-in workflow types

Apps use `WorkflowStage` and `WorkflowRequirements` from `langboard_sdk`:

```python
from langboard_sdk import WorkflowRequirements, WorkflowStage

requirements = WorkflowRequirements(
    (WorkflowStage.ACTIVE, WorkflowStage.REVIEW, WorkflowStage.CLOSED),
    (WorkflowStage.READY,),
)
descriptor = requirements.to_dict()
```

These are Langboard's built-in global types, not app-owned stages. The wizard
maps these types to the board's existing columns; it never inserts app-specific
workflow definitions. SDK validation rejects unknown and duplicate types. The
host checks the current built-in registry, activation and column access before
accepting a mapping. Display names and translations remain host-owned.


## App governance contracts

`GovernanceManager` reads and updates instance/organization app policy over the
caller's authenticated transport. Policies are `disabled`, `approved_only` and
`personal_allowed`; organization policy can only restrict instance policy.
Organization shared automation requires an organization connection. Personal
connections never inherit that authority. Mutations require current SHA256
revisions; organization `mode=None` restores inheritance.

Optional schema-v1 `publisher`, `trust` origin arrays and finite `mcp` tool
declarations are validated locally. HTTPS origins are canonical and bounded;
HTTP localhost is rejected. Declaring an MCP tool grants no execution authority.
`declaration_trust_fingerprint` and `update_consent` preserve reviewed capability
intersections for ordinary updates, clear grants when publisher/destinations/MCP
identity/exact panel URL change, and leave added capabilities ungranted.

See [GUIDE.md](GUIDE.md#organization-and-personal-app-governance) for exact fields,
admin endpoints, review/readback examples and host compatibility requirements.
These pure contracts and client methods require no host imports. A deployed host
must separately implement and enforce governance APIs and per-tool grants.

## Board read revocation (0.2.1)

Both provider managers expose `disable_read(connection_uid, connection_revision, binding_revision)`. It revokes board-wide read grants without disconnecting the external account, removing resource selections, deleting observations or revoking independent panel/workflow grants. Use revisions from the latest selected-resource snapshot. Compatible hosts must implement the authenticated `disable-read` route; older hosts can reject this additive operation. It neither cancels already accepted external operations nor grants new permissions.

## Inbound connection identity (0.2.2)

`ConnectionCredentials` uses a separately user-authenticated transport for explicit
owner-managed issue/revoke operations. `AppIdentity` uses an app credential
transport for the server-derived current identity. They reuse `HttpTransport`;
neither stores tokens, refreshes them automatically, retries mutations, nor
grants execution permissions. Compatible hosts must implement the credential
routes and `/apps/v1/identity`; older hosts may reject these additive operations.

## App connection resources (0.2.3)

`AppResources(app_transport).list(board_uid, limit=25, after_uid=None)` reads one
bounded page from `/apps/v1/boards/{board_uid}/resources`. Use the separate app
Bearer transport configured for `AppIdentity`. The `AppResourcePage` and
`AppResource` TypedDicts describe the native response. Pass `next_cursor` as
`after_uid` explicitly to read another page. No automatic crawling, token
refresh, retries or credential storage is performed. Each request rechecks
current connection consent, policy, membership, board binding and resource access
on the host. Identity and resource visibility grant no card execution authority.
Hosts without this additive route may return a native API error.


## Card resource configuration (0.2.12)

`CardResources` uses a human administrator transport, separately from app-scoped
`AppResources`. Read the current selection before replacing it:

```python
from langboard_sdk import CardResources

resources = CardResources(user_transport)
current = await resources.read(board_uid, card_uid, connection_uid)
saved = await resources.select(
    board_uid, card_uid, connection_uid, selected_resource_uids,
    expected_revision=current["revision"],
)
```

Select at most 20 distinct native resource UIDs. Empty selection explicitly
unlinks resources, including authorized cleanup after consent revocation. The
initial revision is null; replacements require the current positive revision.
No automatic retry, conflict recovery, resource discovery or execution grant is
performed. After a lost response, read back before deciding whether to retry.
The compatible host checks current card visibility, board administration,
connection ownership, resource grants and consent. App credentials cannot
configure human-owned selections. SDK 0.2.12 requires the host card-resource
GET/PUT routes; older hosts may return 404.


### Enumerate retained selections (0.2.13)

```python
page = await resources.list_selections(board_uid, card_uid)
for selection in page["items"]:
    # The connection and revision are current-owner configuration receipts.
    # Clear only selections the human explicitly requested to unlink.
    print(selection["app_key"], selection["connection_uid"], selection["revision"])
if page["next_cursor"] is not None:
    next_page = await resources.list_selections(
        board_uid, card_uid, after_uid=page["next_cursor"],
    )
```

Each call returns at most 25 current-owner selections. Disconnected connections
remain available for authorized cleanup; another user's personal connection is
not disclosed. This is configuration metadata, never an execution grant or
credential discovery. Pagination is explicit; the SDK does not fetch every page
or retry a failed request. Older hosts without the listing route return 404.

## App-owned interaction validation (0.2.14)

`validate_card_interaction` validates localized stable-ID choices for approval, questions and non-agent actions. It accepts optional execution context, typed response cardinality, native workflow stage outcomes, and explicit reaction/comment binding. This is request validation only; it neither approves a choice nor dispatches an external action. Human response and UI lifecycle methods remain pending.

### App request cancellation (0.2.16)

`AppCardInteractions.cancel(board_uid, card_uid, interaction_uid,
expected_revision=revision)` calls the host cancellation endpoint. Retain the
original revision when retrying an ambiguous response. A changed cancellation
increments the stored revision; its exact retry returns `changed: false`.
Cancellation preserves the immutable request and does not cancel or resume an
external runtime. Current app authentication and scope are required. Expired
requests remain expired; stale revisions conflict. This requires a host that
implements the app cancellation route; older hosts may return 404. Human response,
signed delivery and continuation are not provided by this method.

### Choice or text questions (0.2.17)

An interaction of kind `question` may declare a question with
`type: "choice_or_text"`, stable `choices` and a required integer `max_length`
between 1 and 16000. This lets the UI offer exactly one predefined choice or
custom non-secret text without replacing choice identities with display labels.
The request still requires localized prompts and English fallback. Secret fields
are rejected. Approval and action requests cannot use this question type;
comment-reaction presentation cannot represent custom text.

Workflow outcomes may name declared choice IDs only. Custom text has no implicit
workflow outcome or approval meaning. The future response API must accept exactly
one of a declared `choice_id` or bounded `text` for this question, never both.
This package validates and stores requests; response acceptance and UI remain
host implementation gates. Older hosts reject unsupported question types, so
consumers must explicitly target a host consuming SDK 0.2.17 or later. There is
no silent fallback to free text. Provider option labels and mappings belong in
the external app, not the host contract.

### Human value validation (0.2.18)

`validate_card_interaction_values(immutable_request, values)` validates a frozen
JSON answer map keyed by every declared question ID, capped at 32 KiB. Single
choice uses `{"choice_id": "stable-id"}`; multiple choice uses
`{"choice_ids": ["stable-id"]}` with the declared count limits and no duplicates.
Free text uses `{"text": "non-empty bounded text"}`. A `choice_or_text` answer
contains exactly one of `choice_id` or `text`. Labels cannot identify choices.
Missing/extra questions, unknown fields, non-finite JSON and invalid answer types
are rejected. Text is preserved exactly after validation, not stripped or
interpreted as instructions. Approval uses the existing approve/reject choice IDs.

This validates values only. It does not authenticate a responder, accept a response,
change workflow, deliver an event, or resume execution. A host response operation
must validate current access, revision, generation, expiry and app authority before
persisting a receipt. The host must apply this same validator to the stored request.

### Signed response delivery and reception (0.2.19)

When explicitly enabled on the host, `io.langboard.app.interaction.answered.v1`
is delivered through the owning connection's approved signed webhook. Authenticate
exact bytes with `verify_webhook` before parsing; persist `event_uid` and the
local reception receipt atomically to suppress duplicates. The event includes
stable interaction/response IDs, actor, values and optional execution context.
Read the current interaction with `AppCardInteractions.read` before authorizing
any continuation. A signature or a previously accepted response is not current
execution permission. Do not apply native column outcomes in the external app.

`AppCardInteractions.acknowledge(board_uid, card_uid, interaction_uid,
event_uid=event_uid, runtime_reference=stable_reference)` persists reception using
the app's own authenticated transport. Exact retries retain the same receipt;
changing the event or runtime reference conflicts. The host accepts only delivered
or live-claimed events under current authority. Returned `state: received` and
`execution_resumed: false` mean reception only. Execution commands, observed
continuation, provider actions and UI remain separate contracts. Older hosts may
return 404. `read` exposes `response`, `delivery_state`, `acknowledgment_uid` and
`reception_state` when an accepted response exists. No automatic polling, retry or
resume is performed by this SDK method.

## External signal policies (0.2.21)

External apps may declare `signal_policy` with `version: 1`, finite unique
`event_types` and `resource_types` (1–16 each), and a finite `outcome_states` map
from app outcomes to `passed`, `failed`, `resolved`, `ignored`, `queued`,
`running`, `cancelled` or `unknown`. Resources must belong to the app declaration.
`commit_mode` is `required`, `empty` or `optional`; `time_basis` is
`provider_occurrence` or `observation`. All six fields are required and unknown
fields are rejected. This expresses evidence semantics, never human approval.

The policy requires `signals.read`. Optional `signals.publish` additionally
requires this policy and remains separate from panel rendering, reads and card
creation. A policy change requires renewed read/publication consent while
retaining unrelated grants. Registration alone never authorizes ingestion.
Compatible host approval, signed ingestion, resource authority and replay
validation remain required; no ingestion endpoint is implemented by this SDK
version. Existing HITL request/response/ACK bodies are unchanged.

Version 0.2.22 adds `AppSignals(HttpTransport(session), credential).publish(board_uid,
envelope)` for compatible native signed ingress. It sends canonical exact JSON
bytes and native v1 timestamp/HMAC headers using an explicitly supplied owner-issued
connection credential. The server remains responsible for current consent,
connection/resource/SecretRef authority and event policy validation. The caller
owns the session timeout and credential lifecycle. The SDK performs one POST;
ambiguous results raise `MutationOutcomeUnknown` without retrying or generating a
new event identity. Persist the original envelope/event ID before sending and
reconcile before an explicit retry. Signal publication never creates a card or
approves a human request.


Version 0.2.23 exposes explicit board consent independently of workflow mapping:
`AppManager(transport, board_uid).prepare_consent(app_key, app_revision)` obtains a
disabled binding with no grants. Use its UID and revision in `set_consent(app_key,
app_revision, binding_uid, expected_revision, capabilities)` only after user approval.
An empty capability list withdraws consent. The server validates declaration,
current authority and revision; no provider name is embedded in these methods.
No ambiguous mutation is automatically retried. This requires a host supporting
the POST consent preparation endpoint; older hosts reject it. HITL wire is unchanged.

Signal publication validates native signal_uid and boolean duplicate receipts.
Malformed success responses raise MutationOutcomeUnknown without retrying.
Preserve the original envelope and reconcile before explicit replay.


SDK 0.2.31 adds `AppExecution.request_review` for native Review after a retained app start and stopped report. Current owning-app consent, resources, generation, card revision and explicit built-in Review mapping are checked independently of the stopped permit. Pass current card/binding revisions from `AppCards.read`; retain the original inputs on an ambiguous retry. A result reference is app attestation, not proof of human acceptance; this method cannot move to Done or Archive. Compatible host support is required.
