"""Current app-owned card content. Read receipts do not authorize execution."""

from .resources import _uid
from .rest import ApiTransport


class AppCards:
    def __init__(self, transport: ApiTransport):
        self.transport = transport

    async def read(self, board_uid: str, card_uid: str, *, offset: int = 0, limit: int = 16000) -> dict:
        board_uid, card_uid = _uid(board_uid), _uid(card_uid)
        if type(offset) is not int or offset < 0 or type(limit) is not int or not 1 <= limit <= 16000:
            raise ValueError("Invalid card content window")
        return await self.transport.request("GET", f"/apps/v1/boards/{board_uid}/cards/{card_uid}",
                                            params={"offset": offset, "limit": limit})
