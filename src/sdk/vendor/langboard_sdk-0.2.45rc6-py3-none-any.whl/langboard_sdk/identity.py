"""Inbound connection identity, separate from owner management authority."""

import re

from .management import _positive, _request_id, _revision, _segment
from .rest import ApiTransport


class ConnectionCredentials:
    """Use a user-authenticated transport. Tokens are never fetched implicitly."""

    def __init__(self, transport: ApiTransport):
        self.transport = transport

    async def issue(self, connection_uid: str, *, expires_in_seconds: int = 3600) -> dict:
        if type(expires_in_seconds) is not int or not 60 <= expires_in_seconds <= 86400:
            raise ValueError("Credential lifetime must be 60 to 86400 seconds")
        return await self.transport.request(
            "POST", f"/settings/apps/connections/{_segment(connection_uid)}/credentials",
            json={"expires_in_seconds": expires_in_seconds},
        )

    async def revoke(self, connection_uid: str, credential_uid: str) -> dict:
        return await self.transport.request(
            "POST", f"/settings/apps/connections/{_segment(connection_uid)}/credentials/{_segment(credential_uid)}/revoke",
        )

    async def custody(self, connection_uid: str) -> dict:
        """Read owner-scoped review metadata; never obtain the service bearer."""
        return await self.transport.request(
            "GET", f"/settings/apps/connections/{_segment(connection_uid)}/credential-custody",
        )

    async def approve_custody(
        self, connection_uid: str, *, expected_connection_revision: str,
        expected_destination_revision: int, expected_revision: int | None = None,
    ) -> dict:
        """Explicit user approval of the currently reviewed connection and target."""
        return await self.transport.request(
            "POST", f"/settings/apps/connections/{_segment(connection_uid)}/credential-custody",
            json={
                "expected_connection_revision": _revision(expected_connection_revision),
                "expected_destination_revision": _positive(expected_destination_revision),
                "expected_revision": None if expected_revision is None else _positive(expected_revision),
            },
        )

    async def handoff_custody(
        self, custody_uid: str, *, expected_revision: int, request_id: str,
        notification_challenge_uid: str | None = None,
        notification_challenge_token: str | None = None,
    ) -> dict:
        """Request one fixed-target handoff; its receipt grants no destination approval.

        The optional challenge pair travels only in the request body. Keep it out
        of URLs, logs and browser storage. Ambiguous outcomes are not retried.
        """
        body = {"expected_revision": _positive(expected_revision), "request_id": _request_id(request_id)}
        if notification_challenge_uid is not None or notification_challenge_token is not None:
            if (
                not isinstance(notification_challenge_uid, str)
                or not re.fullmatch(r"[A-Za-z0-9]{11}", notification_challenge_uid)
                or not isinstance(notification_challenge_token, str)
                or not re.fullmatch(r"[A-Za-z0-9_-]{43}", notification_challenge_token)
            ):
                raise ValueError("A complete native notification challenge pair is required")
            body.update(notification_challenge_uid=notification_challenge_uid,
                        notification_challenge_token=notification_challenge_token)
        return await self.transport.request(
            "POST", f"/settings/apps/credential-custody/{_segment(custody_uid)}/handoff", json=body,
        )

    async def revoke_custody(self, custody_uid: str, *, expected_revision: int) -> dict:
        """Explicit user withdrawal, fenced by the reviewed custody revision."""
        return await self.transport.request(
            "POST", f"/settings/apps/credential-custody/{_segment(custody_uid)}/revoke",
            json={"expected_revision": _positive(expected_revision)},
        )


class AppIdentity:
    """Use a separately configured app credential transport. Identity grants no capabilities."""

    def __init__(self, transport: ApiTransport):
        self.transport = transport

    async def current(self) -> dict:
        return await self.transport.request("GET", "/apps/v1/identity")
