"""Current-user card deadline queries; authorization remains native."""

from typing import Literal
from .rest import ApiTransport


class ScheduleQueries:
    """Use a user-authenticated transport, not an app connection credential.

    These are readable card deadlines, not a separate calendar event aggregate.
    The native API validates timezone-aware ranges, cursors and current access.
    This client grants no delegation and creates no subscription or reminder.
    """

    def __init__(self, transport: ApiTransport):
        self.transport = transport

    async def list(
        self, start: str, end: str, *, scope: Literal["personal", "board"] = "personal",
        project_uid: str | None = None, cursor: str | None = None, limit: int = 50,
    ) -> dict:
        params = {"start": start, "end": end, "scope": scope, "limit": limit}
        if project_uid is not None:
            params["project_uid"] = project_uid
        if cursor is not None:
            params["cursor"] = cursor
        return await self.transport.request("GET", "/dashboard/schedule", params=params)
