"""External service declarations. Registration never grants execution authority."""

import json
import re
from urllib.parse import urlsplit
from .workflow import WorkflowRequirements
from .lifecycle import validate_card_lifecycle
from .card_interactions import validate_card_interactions
from .signals import validate_signal_policy


APP_CAPABILITIES = frozenset({"cards.read", "cards.create", "cards.presentation", "resources.read", "events.receive", "transfers.receive", "panels.render", "signals.read", "signals.publish", "execution.run", "interactions.request", "mcp.read", "mcp.write", "mcp.automation"})


def validate_app_definition(item: dict) -> dict:
    allowed = {"schema_version", "key", "version", "name", "description", "capabilities", "resource_types", "workflow_requirements", "panel", "publisher", "trust", "mcp", "card_lifecycle", "card_interactions", "signal_sources", "signal_policy", "notification_onboarding"}
    if not isinstance(item, dict) or set(item) - allowed or len(json.dumps(item)) > 16384:
        raise ValueError("Invalid app declaration")
    if type(item.get("schema_version")) is not int or item["schema_version"] not in (1, 2):
        raise ValueError("Unsupported app declaration schema")
    if not isinstance(item.get("key"), str) or not re.fullmatch(r"[a-z][a-z0-9_-]{0,31}", item["key"]):
        raise ValueError("Invalid app key")
    if not isinstance(item.get("version"), str) or not re.fullmatch(r"(0|[1-9][0-9]{0,5})\.(0|[1-9][0-9]{0,5})\.(0|[1-9][0-9]{0,5})", item["version"]):
        raise ValueError("App version must be major.minor.patch")
    for field, maximum in (("name", 80), ("description", 1000)):
        if not isinstance(item.get(field), str) or not item[field].strip() or len(item[field]) > maximum:
            raise ValueError("App needs bounded English fallback text")
    for field in ("capabilities", "resource_types"):
        values = item.get(field)
        if not isinstance(values, list) or len(values) > 16 or any(not isinstance(v, str) for v in values) or len(set(values)) != len(values):
            raise ValueError("Invalid app capability/resource declaration")
    if "signal_sources" in item:
        sources = item["signal_sources"]
        if (not isinstance(sources, list) or not 1 <= len(sources) <= 16
            or any(not isinstance(source, str) or not re.fullmatch(r"[a-z][a-z0-9_-]{0,31}", source) for source in sources)
            or len(set(sources)) != len(sources) or "signals.read" not in item["capabilities"]):
            raise ValueError("Signal sources require unique bounded adapter keys and signals.read")
    if set(item["capabilities"]) - APP_CAPABILITIES:
        raise ValueError("Unsupported app capability")
    if "transfers.receive" in item["capabilities"] and not {"cards.read", "resources.read", "events.receive"} <= set(item["capabilities"]):
        raise ValueError("Transfers require explicit card, resource and event read capabilities")
    if "signal_policy" in item:
        if "signals.read" not in item["capabilities"]:
            raise ValueError("Signal policy requires signals.read")
        validate_signal_policy(item["signal_policy"], item["resource_types"])
    if "signals.publish" in item["capabilities"] and "signal_policy" not in item:
        raise ValueError("Signal publication requires an explicit policy")
    if item["schema_version"] == 2 and "cards.create" in item["capabilities"] and "card_lifecycle" not in item:
        raise ValueError("Card-producing apps require explicit lifecycle policies")
    if "card_lifecycle" in item:
        validate_card_lifecycle(item["card_lifecycle"])
    if "card_interactions" in item:
        validate_card_interactions(item["card_interactions"])
    if any(not re.fullmatch(r"[a-z][a-z0-9_-]{0,63}", v) for v in item["resource_types"]):
        raise ValueError("Invalid app resource type")
    if "publisher" in item:
        _text(item["publisher"], 200, "publisher")
    if "trust" in item:
        trust = item["trust"]
        fields = {"authentication_origins", "mcp_origins", "data_origins"}
        if not isinstance(trust, dict) or set(trust) != fields:
            raise ValueError("Trust requires authentication, MCP and data origin arrays")
        for origins in trust.values():
            if not isinstance(origins, list) or len(origins) > 16:
                raise ValueError("Trust origins must be bounded arrays")
            for origin in origins:
                _origin(origin)
            if len(set(origins)) != len(origins):
                raise ValueError("Trust origins must be unique")
    if "notification_onboarding" in item:
        onboarding = item["notification_onboarding"]
        if not isinstance(onboarding, dict) or set(onboarding) != {"url"}:
            raise ValueError("Notification onboarding requires exactly a URL")
        target = onboarding["url"]
        if (not isinstance(target, str) or not target or len(target) > 2048
                or any(char.isspace() or ord(char) < 32 or ord(char) == 127 for char in target)
                or "?" in target or "#" in target or "\\" in target
                or re.search(r"%(?![0-9A-Fa-f]{2})", target)):
            raise ValueError("Invalid notification onboarding URL")
        parsed = urlsplit(target)
        origin = f"{parsed.scheme}://{parsed.netloc}"
        _origin(origin)
        if (not target.startswith(origin) or parsed.query or parsed.fragment
                or "events.receive" not in item["capabilities"]
                or origin not in item.get("trust", {}).get("data_origins", [])):
            raise ValueError("Notification onboarding requires events.receive and an approved data origin")
    if "mcp" in item:
        mcp = item["mcp"]
        if not isinstance(mcp, dict) or set(mcp) != {"identity", "tools"}:
            raise ValueError("MCP declaration requires identity and finite tools")
        _text(mcp["identity"], 200, "MCP identity")
        if not isinstance(mcp["tools"], list) or len(mcp["tools"]) > 64:
            raise ValueError("MCP tools must be a bounded array")
        names = set()
        for tool in mcp["tools"]:
            if not isinstance(tool, dict) or set(tool) != {"name", "description", "authority_scope"}:
                raise ValueError("Invalid MCP tool declaration")
            if not isinstance(tool["name"], str) or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_.-]{0,63}", tool["name"]):
                raise ValueError("Invalid MCP tool name")
            _text(tool["description"], 1000, "MCP tool description")
            if tool["authority_scope"] not in ("read", "write", "automation") or tool["name"] in names:
                raise ValueError("Invalid or duplicate MCP tool authority declaration")
            names.add(tool["name"])
    workflow = item.get("workflow_requirements")
    if workflow is not None:
        if not isinstance(workflow, dict) or set(workflow) != {"required", "optional"}:
            raise ValueError("Invalid workflow requirements")
        if any(not isinstance(workflow[k], list) for k in ("required", "optional")):
            raise ValueError("Invalid workflow requirements")
        WorkflowRequirements(tuple(workflow["required"]), tuple(workflow["optional"]))
    panel = item.get("panel")
    if panel is not None:
        if not isinstance(panel, dict) or set(panel) != {"url", "name", "icon"}:
            raise ValueError("Invalid app panel declaration")
        for field, maximum in (("url", 2048), ("name", 80), ("icon", 32)):
            if not isinstance(panel[field], str) or not panel[field].strip() or len(panel[field]) > maximum:
                raise ValueError("Invalid app panel text")
        url = urlsplit(panel["url"])
        if url.scheme != "https" or not url.hostname or url.username or url.password or url.fragment:
            raise ValueError("App panel requires an HTTPS URL without credentials or fragment")
        # Parsing a port also rejects malformed authorities; no network request here.
        _ = url.port
    return json.loads(json.dumps(item))


def _text(value, maximum, field):
    if not isinstance(value, str) or not value.strip() or len(value) > maximum:
        raise ValueError(f"Invalid {field} text")


def _origin(value):
    """Accept exact canonical HTTPS origins, with no development exceptions."""
    _text(value, 2048, "trust origin")
    if any(char.isspace() or ord(char) < 32 for char in value):
        raise ValueError("Invalid trust origin")
    url = urlsplit(value)
    if (url.scheme != "https" or not url.hostname or url.username is not None
            or url.password is not None or url.path or url.query or url.fragment):
        raise ValueError("Trust target must be a canonical HTTPS origin")
    host = url.hostname
    if ":" in host:
        import ipaddress
        host = f"[{ipaddress.IPv6Address(host).compressed}]"
    elif not re.fullmatch(r"[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?", host):
        raise ValueError("Invalid origin hostname")
    elif any(not re.fullmatch(r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?", part) for part in host.split(".")):
        raise ValueError("Invalid origin hostname")
    port = url.port
    canonical = f"https://{host}" + (f":{port}" if port is not None and port != 443 else "")
    if value != canonical:
        raise ValueError("Trust target must be a canonical HTTPS origin")
