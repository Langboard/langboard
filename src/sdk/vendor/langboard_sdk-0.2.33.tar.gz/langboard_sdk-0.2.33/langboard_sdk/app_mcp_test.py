from types import SimpleNamespace
from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock
from .app_mcp import AppMcp


class AppMcpTests(IsolatedAsyncioTestCase):
    async def test_catalog_read_scope_and_no_retry(self):
        transport = SimpleNamespace(request=AsyncMock(side_effect=TimeoutError("unknown")))
        with self.assertRaises(TimeoutError):
            await AppMcp(transport).catalog("ABCDEFGHIJK", "0123456789A")
        self.assertEqual(transport.request.await_count, 1)
        self.assertEqual(transport.request.await_args.args,
                         ("GET", "/apps/v1/boards/ABCDEFGHIJK/cards/0123456789A/mcp-tools"))
        transport.request.reset_mock()
        with self.assertRaises(ValueError):
            await AppMcp(transport).catalog("../board", "0123456789A")
        transport.request.assert_not_awaited()
