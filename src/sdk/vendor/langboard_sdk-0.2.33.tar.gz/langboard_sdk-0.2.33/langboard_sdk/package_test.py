import json
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile
import unittest
from .package import build_package


class PackageTests(unittest.TestCase):
    def test_deterministic_public_package_and_secret_rejection(self):
        with TemporaryDirectory() as directory:
            root = Path(directory)
            panel = root / 'panel'
            panel.mkdir()
            (panel / 'index.html').write_text('<main>Panel</main>')
            declaration = {'schema_version': 1, 'key': 'example-panel', 'version': '1.0.0', 'name': 'Example', 'description': 'Portable panel', 'capabilities': ['panels.render'], 'resource_types': [], 'panel': {'url': 'https://panel.example/', 'name': 'Example', 'icon': 'app'}}
            manifest = root / 'manifest.json'
            manifest.write_text(json.dumps({'package_version': 1, 'declaration': declaration, 'panel_entry': 'panel/index.html'}))
            a = build_package(manifest, panel, root / 'a.zip')
            b = build_package(manifest, panel, root / 'b.zip')
            assert a.read_bytes() == b.read_bytes()
            with ZipFile(a) as archive:
                assert archive.namelist() == ['manifest.json', 'panel/index.html']
            (panel / '.env').write_text('secret')
            with self.assertRaisesRegex(ValueError, 'Only public static'):
                build_package(manifest, panel, root / 'secret.zip')
