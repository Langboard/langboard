"""Current app-owned card content. Read receipts do not authorize execution."""

from .resources import _uid
from .rest import ApiTransport


class AppCards:
    def __init__(self, transport: ApiTransport):
        self.transport = transport

    async def read(self, board_uid: str, card_uid: str, *, offset: int = 0, limit: int = 16000) -> dict:
        board_uid, card_uid = _uid(board_uid), _uid(card_uid)
        if type(offset) is not int or offset < 0 or type(limit) is not int or not 1 <= limit <= 16000:
            raise ValueError("Invalid card content window")
        return await self.transport.request("GET", f"/apps/v1/boards/{board_uid}/cards/{card_uid}",
                                            params={"offset": offset, "limit": limit})

    async def report_archive_outcome(self, board_uid: str, archive_uid: str, *, expected_revision: int,
                                     state: str, external_state: str | None, readback_confirmed: bool) -> dict:
        """Report a provider outcome using a connection credential, without executing or retrying it.

        Keep the original revision and outcome on an ambiguous retry. Successful
        transport is not proof of an external change; applied states require readback.
        """
        board_uid, archive_uid = _uid(board_uid), _uid(archive_uid)
        if type(expected_revision) is not int or expected_revision < 0:
            raise ValueError("A nonnegative outcome revision is required")
        if state not in ("applied", "already_applied", "failed", "blocked", "unknown") or type(readback_confirmed) is not bool:
            raise ValueError("Invalid archive outcome")
        if external_state is not None and (not isinstance(external_state, str) or not external_state.strip() or len(external_state) > 64):
            raise ValueError("Invalid provider state")
        if state in ("applied", "already_applied") and (not readback_confirmed or not external_state):
            raise ValueError("Applied outcomes require provider state readback")
        return await self.transport.request("POST", f"/apps/v1/boards/{board_uid}/archives/{archive_uid}/outcome", json={
            "expected_revision": expected_revision,
            "outcome": {"state": state, "external_state": external_state, "readback_confirmed": readback_confirmed},
        })
