# App protocol

Shared wire constants and TypeScript types for the panel client and host runtime.
The initial extraction preserves protocol version 1. It does not add an endpoint,
authentication mechanism, resource grant or business command.

`protocol.schema.json` is the canonical request envelope and operation list.
The runtime additionally checks JSON UTF-8 size, depth, safe properties and
concurrent request limits. These checks remain shared source, not app-specific
implementations. The internal validator module is not a supported package export.

From the repository root:

```sh
node scripts/generate-protocol.mjs --check
python3 check.py
```

Change the schema and regenerate its constants/types together. Compatibility
tests must still prove the supported old/new client and runtime combinations.
A recognized operation is not evidence that a native host grants permission.

The proposed optional `connections.read` capability identifies host-registered
provider reads without exposing an HTTP proxy. See the [request and ownership
contract](../../docs/connection-reads.md). Source support is not deployed host support.
