import unittest
from unittest.mock import AsyncMock
from .interactions import AppCardInteractions, validate_card_interaction, validate_card_interaction_values

BASE = {
    "schema_version": 1,
    "kind": "question",
    "app_request_key": "deploy-choice",
    "prompt": {"en": "Choose", "ko": "선택"},
    "questions": [
        {
            "id": "action",
            "prompt": {"en": "Action"},
            "type": "single_choice",
            "choices": [
                {"id": "review", "label": {"en": "Review"}},
                {"id": "retry", "label": {"en": "Retry"}},
            ],
        }
    ],
    "presentation": {"type": "choice_card"},
    "outcomes": {"review": {"workflow_stage": "review"}},
    "expires_at": "2026-10-12T00:00:00+00:00",
}


class InteractionTests(unittest.TestCase):
    def test_choice_or_text_preserves_choices_and_bounded_input(self):
        question = {**BASE["questions"][0], "type": "choice_or_text", "max_length": 2000}
        request = {**BASE, "questions": [question]}
        saved = validate_card_interaction(request)
        self.assertEqual(saved["questions"][0], question)
        self.assertEqual(saved["outcomes"], BASE["outcomes"])
        saved["questions"][0]["choices"][0]["label"]["en"] = "Changed"
        self.assertEqual(question["choices"][0]["label"]["en"], "Review")

    def test_choice_or_text_rejects_unbounded_secret_or_implicit_outcomes(self):
        question = {**BASE["questions"][0], "type": "choice_or_text", "max_length": 2000}
        invalid = [
            {**question, "max_length": limit} for limit in (True, 0, 16001, "2000", None)
        ] + [
            {key: value for key, value in question.items() if key != "max_length"},
            {**question, "is_secret": True},
            {**question, "secret": False},
            {**question, "choices": []},
        ]
        for q in invalid:
            with self.subTest(q=q), self.assertRaises(ValueError):
                validate_card_interaction({**BASE, "questions": [q]})
        with self.assertRaises(ValueError):
            validate_card_interaction({**BASE, "questions": [question],
                "outcomes": {"other": {"workflow_stage": "review"}}})

    def test_choice_or_text_cannot_be_approval_action_or_reaction(self):
        question = {**BASE["questions"][0], "type": "choice_or_text", "max_length": 2000}
        for kind in ("approval", "action"):
            with self.subTest(kind=kind), self.assertRaises(ValueError):
                validate_card_interaction({**BASE, "kind": kind, "questions": [question]})
        with self.assertRaises(ValueError):
            validate_card_interaction({**BASE, "questions": [question], "presentation": {
                "type": "comment_reaction", "comment_uid": "A" * 11,
                "reactions": {"thumbs-up": "review", "thumbs-down": "retry"}}})

    def test_valid_and_non_mutating(self):
        item = validate_card_interaction(BASE)
        self.assertEqual(item["questions"][0]["choices"][0]["id"], "review")
        self.assertEqual(BASE["presentation"]["type"], "choice_card")

    def test_approval_requires_explicit_choices(self):
        item = {
            **BASE,
            "kind": "approval",
            "outcomes": {},
            "questions": [
                {
                    **BASE["questions"][0],
                    "choices": [
                        {"id": "approve", "label": {"en": "Approve"}},
                        {"id": "reject", "label": {"en": "Reject"}},
                    ],
                }
            ],
        }
        self.assertEqual(validate_card_interaction(item)["kind"], "approval")

    def test_reaction_requires_current_comment_mapping(self):
        item = {
            **BASE,
            "presentation": {
                "type": "comment_reaction",
                "comment_uid": "A" * 11,
                "reactions": {"thumbs-up": "review", "thumbs-down": "retry"},
            },
        }
        self.assertEqual(
            validate_card_interaction(item)["presentation"]["type"], "comment_reaction"
        )

    def test_rejects_label_as_identity_and_expired_missing_timezone(self):
        item = {
            **BASE,
            "questions": [
                {
                    **BASE["questions"][0],
                    "choices": [{"id": "Review", "label": {"en": "Review"}}],
                }
            ],
        }
        with self.assertRaises(ValueError):
            validate_card_interaction(item)
        with self.assertRaises(ValueError):
            validate_card_interaction({**BASE, "expires_at": "2026-10-12T00:00:00"})

    def test_rejects_unknown_stage_and_reaction(self):
        with self.assertRaises(ValueError):
            validate_card_interaction(
                {**BASE, "outcomes": {"review": {"workflow_stage": "unknown"}}}
            )
        with self.assertRaises(ValueError):
            validate_card_interaction(
                {
                    **BASE,
                    "presentation": {
                        "type": "comment_reaction",
                        "comment_uid": "A" * 11,
                        "reactions": {"rocket": "review"},
                    },
                }
            )


class InteractionValuesTests(unittest.TestCase):
    def test_values_use_ids_and_are_frozen(self):
        values = {"action": {"choice_id": "review"}}
        saved = validate_card_interaction_values(BASE, values)
        saved["action"]["choice_id"] = "retry"
        self.assertEqual(values["action"]["choice_id"], "review")

    def test_choice_or_text_exclusive_and_bounded(self):
        request = {**BASE, "questions": [{**BASE["questions"][0],
                    "type": "choice_or_text", "max_length": 5}]}
        for answer in ({"choice_id": "retry"}, {"text": "한글abc"}):
            self.assertEqual(validate_card_interaction_values(request, {"action": answer})["action"], answer)
        for answer in ({}, {"choice_id": "Review"}, {"text": "      "},
                       {"text": "abcdef"}, {"text": True},
                       {"text": "ok", "choice_id": "retry"}, {"text": "ok", "secret": True}):
            with self.subTest(answer=answer), self.assertRaises(ValueError):
                validate_card_interaction_values(request, {"action": answer})

    def test_free_text_and_multichoice(self):
        request = {**BASE, "outcomes": {}, "questions": [
            {"id": "note", "prompt": {"en": "Note"}, "type": "free_text", "max_length": 10},
            {**BASE["questions"][0], "type": "multi_choice", "min_selections": 0, "max_selections": 2}]}
        values = {"note": {"text": "Retain me"}, "action": {"choice_ids": ["retry", "review"]}}
        self.assertEqual(validate_card_interaction_values(request, values), values)
        for answer in ({"choice_ids": ["review", "review"]}, {"choice_ids": [True]},
                       {"choice_ids": ["other"]}, {"choice_id": "review"}):
            with self.subTest(answer=answer), self.assertRaises(ValueError):
                validate_card_interaction_values(request, {**values, "action": answer})
        self.assertEqual(validate_card_interaction_values(request,
            {**values, "action": {"choice_ids": []}})["action"], {"choice_ids": []})
        request["questions"][1]["min_selections"] = 1
        with self.assertRaises(ValueError):
            validate_card_interaction_values(request, {**values, "action": {"choice_ids": []}})

    def test_missing_extra_or_non_json_values(self):
        for values in ({}, {"action": {"choice_id": "review"}, "extra": {}},
                       {"action": "review"}, {"action": {"choice_id": float("nan")}}, []):
            with self.subTest(values=values), self.assertRaises(ValueError):
                validate_card_interaction_values(BASE, values)


class InteractionTransportTests(unittest.IsolatedAsyncioTestCase):
    async def test_cancel_preserves_revision_and_server_receipt(self):
        transport = AsyncMock()
        receipt = {"state": "cancelled", "revision": 2, "changed": False,
                   "execution_resumed": False}
        transport.request.return_value = receipt
        api = AppCardInteractions(transport)
        result = await api.cancel("A" * 11, "B" * 11, "C" * 11, expected_revision=1)
        self.assertIs(result, receipt)
        transport.request.assert_awaited_once_with(
            "POST", f"/apps/v1/boards/{'A' * 11}/cards/{'B' * 11}/interactions/{'C' * 11}/cancel",
            json={"expected_revision": 1},
        )

    async def test_cancel_invalid_inputs_make_no_request(self):
        transport = AsyncMock()
        api = AppCardInteractions(transport)
        for revision in (True, False, 0, -1, 1.0, "1", None):
            with self.subTest(revision=revision), self.assertRaises(ValueError):
                await api.cancel("A" * 11, "B" * 11, "C" * 11, expected_revision=revision)
        for uids in (("bad", "B" * 11, "C" * 11),
                     ("A" * 11, "bad", "C" * 11),
                     ("A" * 11, "B" * 11, "../cancel")):
            with self.subTest(uids=uids), self.assertRaises(ValueError):
                await api.cancel(*uids, expected_revision=1)
        transport.request.assert_not_awaited()


if __name__ == "__main__":
    unittest.main()
