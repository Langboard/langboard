/** Bounded read-only pager shared by independent panels; no timer or credentials. */
export function filterSignals(items, provider, query = '', outcome = '') {
  const search = query.toLocaleLowerCase();
  return items.filter(item => item.provider === provider &&
    (!outcome || (item.conflict ? 'conflict' : item.outcome || 'unknown') === outcome) &&
    [item.resource_name, item.external_id, item.commit_sha, item.event_type]
      .some(value => String(value || '').toLocaleLowerCase().includes(search)));
}
export function createSignalInbox(session, provider, changed) {
  if (typeof provider !== 'string' || !/^[a-z][a-z0-9_-]{0,31}$/.test(provider)) {
    throw new TypeError('Invalid signal provider key');
  }
  let state = { items: [], nextCursor: null, busy: false, error: '' };
  const publish = update => { state = {...state, ...update}; if (!session.signal.aborted) changed(state); };
  return {
    async load(more = false) {
      if (state.busy || session.signal.aborted || (more && !state.nextCursor)) return;
      publish({busy: true, error: ''});
      try {
        const result = await session.request('signals.list', {provider, ...(more ? {after: state.nextCursor} : {})});
        if (session.signal.aborted) return;
        if (!result || !Array.isArray(result.items) || result.items.length > 25 ||
          !(result.next_cursor === null || (typeof result.next_cursor === 'string' && /^[A-Za-z0-9]{1,11}$/.test(result.next_cursor)))) {
          throw new Error('Invalid signal inbox response');
        }
        const items = result.items.filter(item => item && typeof item === 'object' && item.provider === provider);
        // UI session cap. Refresh restarts paging; no accumulated unbounded history.
        const combined = more ? [...state.items, ...items] : items;
        if (combined.length > 250) throw new Error('Inbox limit reached; refresh to restart');
        publish({items: combined, nextCursor: result.next_cursor});
      } catch (error) {
        // Permission failures must remove prior evidence, never leave a stale successful view.
        if (!session.signal.aborted) publish({items: [], nextCursor: null, error: error instanceof Error ? error.message : 'Request failed'});
      } finally { if (!session.signal.aborted) publish({busy: false}); }
    },
  };
}

/** Source-scoped UI lifetime. Dispose rejects late state; start supports effect replay. */
export function createSourceInbox(session, provider, changed) {
  // Validate at construction without attaching a listener or requesting data.
  createSignalInbox(session, provider, () => {});
  let inbox, stop;
  return {
    start() {
      if (inbox || session.signal.aborted) return;
      const abort = new AbortController();
      stop = () => abort.abort();
      inbox = createSignalInbox({ signal: abort.signal, request: (...args) => session.request(...args) }, provider,
        state => changed({ ...state, source: provider }));
      session.signal.addEventListener('abort', stop, { once: true });
      return inbox.load();
    },
    load(more = false) { return inbox?.load(more); },
    dispose() {
      stop?.();
      if (stop) session.signal.removeEventListener('abort', stop);
      inbox = undefined; stop = undefined;
    },
  };
}
