from types import SimpleNamespace
from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock
from . import AppCards, validate_app_definition


class CardReadTests(IsolatedAsyncioTestCase):
    async def test_bounded_current_read_and_explicit_capability(self):
        transport = SimpleNamespace(request=AsyncMock(return_value={"card_revision": 7}))
        receipt = await AppCards(transport).read("board000001", "card0000001", offset=10, limit=20)
        self.assertEqual(receipt, {"card_revision": 7})
        transport.request.assert_awaited_once_with("GET", "/apps/v1/boards/board000001/cards/card0000001",
                                                  params={"offset": 10, "limit": 20})
        transport.request.reset_mock()
        for kwargs in ({"offset": True}, {"offset": -1}, {"limit": 0}, {"limit": 16001}):
            with self.assertRaises(ValueError):
                await AppCards(transport).read("board000001", "card0000001", **kwargs)
        transport.request.assert_not_awaited()
        declaration = {"schema_version": 2, "key": "example", "version": "1.0.0",
                       "name": "Example", "description": "Read current owned work",
                       "resource_types": ["issue"], "capabilities": ["cards.read"]}
        self.assertEqual(validate_app_definition(declaration)["capabilities"], ["cards.read"])
