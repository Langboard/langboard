import type { PanelContext, PanelState, PanelDesign, PanelHostDispose, JsonValue, PanelOperation } from "@langboard/app-protocol";
export type { PanelContext, PanelState, PanelDesign, PanelHostDispose } from "@langboard/app-protocol";
export const HOST_RUNTIME_API_VERSION: 1;
export function createPanelHost(options: {
    frame: HTMLIFrameElement;
    context: PanelContext;
    supportedOperations?: readonly PanelOperation[];
    state?: PanelState | null;
    design?: PanelDesign;
    onState?: (state: PanelState) => void;
    onReady?: () => void;
    onClose?: () => void;
    onError?: (error: unknown) => void;
    onRequest?: (operation: PanelOperation, params: JsonValue, signal: AbortSignal) => JsonValue | Promise<JsonValue>;
}): PanelHostDispose;
export class PanelStateCache {
    get(key: string): PanelState | null;
    set(key: string, state: PanelState): void;
    delete(key: string): boolean;
    clear(): void;
}
