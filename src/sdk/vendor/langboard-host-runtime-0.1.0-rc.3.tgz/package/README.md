# Host compatibility runtime

The independent host side of the existing panel MessageChannel transport.
It owns frame initialization, bounded state transport, request dispatch,
timeouts and disposal. `HOST_RUNTIME_API_VERSION` identifies its integration API;
the panel wire protocol has its own version.

The native host supplies its existing authorized `onRequest` adapter. This package
does not own card storage, OAuth consent, roles, workflow decisions or provider
credentials. It must not be used to replace their native checks.

```js
import { createPanelHost } from "@langboard/host-runtime";

const dispose = createPanelHost({
  frame,
  context: { project_uid, app_key, app_version, language },
  onRequest: (operation, params, signal) => nativeAdapter.request(operation, params, signal),
});
// Dispose when the authorized identity, board, app or panel session changes.
dispose();
```

`frame`, the context values and `nativeAdapter` come from the integrating host;
they are not extra SDK exports. Applications remain isolated in their panel.

`npm run build` emits a standalone ESM runtime and a deterministic manifest under
`dist/runtime`. Its checksum describes bytes, not consent, compatibility approval
or a release signature. The host must consume a reviewed artifact and preserve
its native authorization boundary. Actual independent host deployment is not
established merely by building this bundle.

The supported `createPanelHost` and `PanelStateCache` exports remain available
from `@langboard/app-panel` in this prerelease. They re-export this implementation
in source; host integrators can move to the dedicated package without a second
transport implementation.

For an implemented optional native selector, explicitly include `resources.open`
in `supportedOperations`. Passing a list restricts dispatch to that list. Omit it
to preserve only the five legacy operations. The list is a transport capability,
not authorization; never advertise an unimplemented native action. Existing
clients ignore the additive bootstrap metadata and retain their old behavior.
