"""Native app reads and human resource selection, without execution authority."""

import re
from typing import TypedDict, cast
from .rest import ApiTransport
from .management import _revision


class AppResource(TypedDict):
    resource_uid: str
    resource_type: str
    external_resource_id: str
    resource_path: list[dict[str, str]]
    access_revision: int
    health: str


class AppResourcePage(TypedDict):
    schema_version: int
    connection_uid: str
    binding_revision: str
    items: list[AppResource]
    next_cursor: str | None


class CardResourceSelection(TypedDict):
    app_key: str
    connection_uid: str
    revision: int | None
    resource_uids: list[str]


class CardResourceSelectionPage(TypedDict):
    items: list[CardResourceSelection]
    next_cursor: str | None


class CardResourceSelectionUpdate(TypedDict):
    revision: int | None
    changed: bool
    resource_uids: list[str]


def _uid(value: str) -> str:
    if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9]{11}", value):
        raise ValueError("A native 11-character UID is required")
    return value


class AppResources:
    """Use a separate app Bearer transport. Each page rechecks current host authority."""

    def __init__(self, transport: ApiTransport):
        self.transport = transport

    async def list(self, board_uid: str, *, limit: int = 25, after_uid: str | None = None) -> AppResourcePage:
        board_uid = _uid(board_uid)
        if type(limit) is not int or not 1 <= limit <= 50:
            raise ValueError("Resource page limit must be 1 to 50")
        params: dict = {"limit": limit}
        if after_uid is not None:
            params["after"] = _uid(after_uid)
        return cast(AppResourcePage, await self.transport.request(
            "GET", f"/apps/v1/boards/{board_uid}/resources", params=params,
        ))


class CardResources:
    """Human administrator configuration. Use a user transport, never app credentials."""

    def __init__(self, transport: ApiTransport):
        self.transport = transport

    @staticmethod
    def _path(board_uid: str, card_uid: str, connection_uid: str) -> str:
        return f"/board/{_uid(board_uid)}/card/{_uid(card_uid)}/apps/connections/{_uid(connection_uid)}/resources"

    async def list_selections(self, board_uid: str, card_uid: str, *, after_uid: str | None = None) -> CardResourceSelectionPage:
        """List current-owner card selections for cleanup; credentials never appear."""
        board_uid, card_uid = _uid(board_uid), _uid(card_uid)
        params: dict = {}
        if after_uid is not None:
            params["after"] = _uid(after_uid)
        return cast(CardResourceSelectionPage, await self.transport.request(
            "GET", f"/board/{board_uid}/card/{card_uid}/apps/resource-selections", params=params,
        ))

    async def read(self, board_uid: str, card_uid: str, connection_uid: str) -> CardResourceSelection:
        return cast(CardResourceSelection, await self.transport.request(
            "GET", self._path(board_uid, card_uid, connection_uid),
        ))

    async def select(self, board_uid: str, card_uid: str, connection_uid: str,
                     resource_uids: list[str], *, expected_revision: int | None) -> CardResourceSelectionUpdate:
        path = self._path(board_uid, card_uid, connection_uid)
        if not isinstance(resource_uids, list) or len(resource_uids) > 20:
            raise ValueError("Select at most 20 distinct resource UIDs")
        resources = [_uid(uid) for uid in resource_uids]
        if len(set(resources)) != len(resources):
            raise ValueError("Select at most 20 distinct resource UIDs")
        if expected_revision is not None and (type(expected_revision) is not int or expected_revision < 1):
            raise ValueError("A current positive revision or initial null is required")
        return cast(CardResourceSelectionUpdate, await self.transport.request(
            "PUT", path, json={"resource_uids": resources, "expected_revision": expected_revision},
        ))


class BoardResourceSelection(TypedDict):
    resource_uid: str
    resource_type: str
    external_resource_id: str
    resource_path: list[dict[str, str]]
    is_selected: bool
    revision: int
    access_state: str
    health: str


class BoardResourceSelectionPage(TypedDict):
    identity_revision: str
    items: list[BoardResourceSelection]
    next_cursor: str | None


class BoardResourceSelectionUpdate(BoardResourceSelection):
    binding_revision: str


class BoardResources:
    """Use a human management transport; selection does not verify provider access.

    Current board Update permission, connection ownership, consent and revisions
    are enforced by the host. This is not the panel read bridge or an ERP API.
    """

    def __init__(self, transport: ApiTransport):
        self.transport = transport

    @staticmethod
    def _path(board_uid: str, app_key: str, connection_uid: str) -> str:
        if not isinstance(app_key, str) or not re.fullmatch(r"[a-z][a-z0-9_-]{0,31}", app_key):
            raise ValueError("A native app key is required")
        return f"/board/{_uid(board_uid)}/apps/{app_key}/connections/{_uid(connection_uid)}/resources"

    async def list(self, board_uid: str, app_key: str, connection_uid: str,
                   *, limit: int = 25, after_uid: str | None = None) -> BoardResourceSelectionPage:
        path = self._path(board_uid, app_key, connection_uid)
        if type(limit) is not int or not 1 <= limit <= 50:
            raise ValueError("Resource page limit must be 1 to 50")
        params: dict = {"limit": limit}
        if after_uid is not None:
            params["after"] = _uid(after_uid)
        return cast(BoardResourceSelectionPage, await self.transport.request("GET", path, params=params))

    async def select(self, board_uid: str, app_key: str, connection_uid: str, *,
                     resource_type: str, external_resource_id: str, selected: bool,
                     expected_revision: int, expected_binding_revision: str,
                     expected_identity_revision: str, expected_app_revision: str) -> BoardResourceSelectionUpdate:
        """Select or withdraw one resource. Re-read after an ambiguous PUT; never replay automatically."""
        path = self._path(board_uid, app_key, connection_uid)
        if not isinstance(resource_type, str) or not 1 <= len(resource_type) <= 64:
            raise ValueError("Resource type must contain 1 to 64 characters")
        if not isinstance(external_resource_id, str) or not 1 <= len(external_resource_id) <= 512:
            raise ValueError("External resource ID must contain 1 to 512 characters")
        if type(selected) is not bool or type(expected_revision) is not int or expected_revision < 0:
            raise ValueError("Explicit selection and a nonnegative resource revision are required")
        return cast(BoardResourceSelectionUpdate, await self.transport.request("PUT", path, json={
            "resource_type": resource_type, "external_resource_id": external_resource_id,
            "selected": selected, "expected_revision": expected_revision,
            "expected_binding_revision": _revision(expected_binding_revision),
            "expected_identity_revision": _revision(expected_identity_revision),
            "expected_app_revision": _revision(expected_app_revision),
        }))
