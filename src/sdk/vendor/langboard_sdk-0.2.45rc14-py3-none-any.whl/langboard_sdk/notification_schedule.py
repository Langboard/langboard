"""Board-scoped schedule settings for a human administrator."""

from typing import NotRequired, TypedDict

from .client import MutationOutcomeUnknown
from .resources import _uid
from .rest import ApiTransport


class NotificationScheduleCreate(TypedDict):
    name: str
    target: str
    field: str
    operator: str
    is_enabled: NotRequired[bool]
    interval_str: NotRequired[str]
    timezone: NotRequired[str | float]
    value: NotRequired[object]
    recipients: NotRequired[list[str]]
    repeat_after_hours: NotRequired[int]


class NotificationScheduleManager:
    """Use an administrator's native REST session with schedule permissions."""

    _path = "/settings/notification-schedule"

    def __init__(self, transport: ApiTransport):
        self.transport = transport

    async def list_rules(self) -> dict:
        return await self.transport.request("GET", self._path)

    async def create_scoped(self, project_uid: str, rule: NotificationScheduleCreate) -> dict:
        return await self._write("POST", f"{self._path}/rule", _uid(project_uid), dict(rule))

    async def set_project_scope(self, rule_uid: str, project_uid: str) -> dict:
        return await self._write("PUT", f"{self._path}/rule/{_uid(rule_uid)}", _uid(project_uid), {})

    async def _write(self, method: str, path: str, project_uid: str, fields: dict) -> dict:
        settings = await self.list_rules()
        schema = settings.get("notification_rule_schema")
        if not isinstance(schema, dict) or schema.get("project_scope_supported") is not True:
            raise RuntimeError("Langboard host does not advertise board-scoped notification schedules")
        receipt = await self.transport.request(method, path, json={**fields, "project_uid": project_uid})
        rule = receipt.get("notification_rule")
        if not isinstance(rule, dict) or rule.get("project_uid") != project_uid:
            raise MutationOutcomeUnknown("Schedule scope receipt unavailable; read current rules before retrying")
        return rule
