"""Adapter for an already authenticated MCP client, with no provider assumptions."""

from typing import Any
from .client import MutationOutcomeUnknown, _diagnostic_token


class NativeCommandError(RuntimeError):
    """Keep the server error result; callers must inspect state before replaying writes."""

    def __init__(self, command: str, result: Any) -> None:
        super().__init__("Native command returned an error; inspect result and current state before retrying")
        self.command = command
        self.result = result
        payload = getattr(result, "structured_content", None)
        self.code = _diagnostic_token(payload, "code")
        self.request_id = _diagnostic_token(payload, "request_id")


class McpTransport:
    """Use a caller-owned connected FastMCP-style session; do not copy credentials or lifecycle."""

    def __init__(self, client: Any, *, raw_tools: bool = False) -> None:
        if type(raw_tools) is not bool:
            raise ValueError("raw_tools must be a boolean")
        self._client = client
        self._raw_tools = raw_tools

    async def call(self, name: str, arguments: dict[str, Any], *, mutation: bool = False) -> Any:
        try:
            command = "call_raw_tool" if self._raw_tools else name
            payload = {"name": name, "arguments": arguments} if self._raw_tools else arguments
            result = await self._client.call_tool(command, payload, raise_on_error=False)
        except Exception as error:
            if mutation:
                raise MutationOutcomeUnknown("Mutation response unavailable; inspect state before replaying the same request") from error
            raise
        if getattr(result, "is_error", None) is True:
            raise NativeCommandError(name, result)
        value = getattr(result, "structured_content", None)
        if not isinstance(value, dict):
            if mutation:
                raise MutationOutcomeUnknown("Mutation receipt unavailable; inspect state before replaying the same request")
            raise RuntimeError("Native command returned no structured object")
        return value
