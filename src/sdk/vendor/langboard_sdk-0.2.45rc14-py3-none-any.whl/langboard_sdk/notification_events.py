"""Authenticated native notification envelopes; parsing does not authorize delivery."""

import json
from collections.abc import Mapping
from datetime import datetime, timedelta
from urllib.parse import urlsplit
from typing import Literal, NotRequired, TypedDict, cast

from .management import _positive, _segment
from .resources import _uid
from .webhooks import verify_webhook


class NotificationSource(TypedDict):
    notification_uid: str
    type: Literal["assigned_to_card", "mentioned_in_card", "mentioned_in_comment", "card_comment_added", "card_moved", "scheduled_rule", "card_reminder"]
    project_uid: str
    card_uid: str
    comment_uid: NotRequired[str]
    rule_uid: NotRequired[str]
    occurrence_uid: NotRequired[str]


class NotificationActor(TypedDict):
    kind: Literal["user", "bot"]
    uid: str


class NotificationContent(TypedDict):
    title: str
    body: str


class TestNotification(NotificationContent):
    kind: Literal["test"]


class CardActivity(NotificationContent):
    kind: Literal["card_activity"]
    url: str
    source: NotificationSource
    actor: NotificationActor
    reasons: list[str]


class CardDeadline(NotificationContent):
    kind: Literal["card_deadline"]
    url: str
    source: NotificationSource
    actor: NotificationActor
    reasons: list[str]
    deadline_at: str


class CardReminder(NotificationContent):
    kind: Literal["card_reminder"]
    url: str
    source: NotificationSource
    actor: NotificationActor
    reasons: list[str]


class MissedSummary(NotificationContent):
    kind: Literal["missed_summary"]
    count: int
    window_start: str
    window_end: str


class NotificationFence(TypedDict):
    event_revision: int
    subscription_uid: str
    subscription_generation: int
    destination_uid: str
    destination_revision: int


class ExternalDestination(TypedDict):
    kind: Literal["personal", "shared"]
    external_id: str


class EventDestination(TypedDict):
    destination_uid: str
    revision: int


class NotificationEvent(TypedDict):
    schema_version: Literal[1]
    event_uid: str
    event_type: Literal["io.langboard.notification.requested.v1"]
    app_key: str
    connection_uid: str
    notification: TestNotification | CardActivity | CardDeadline | CardReminder | MissedSummary
    notification_fence: NotificationFence
    external_destination: ExternalDestination
    expires_at: str
    destination: EventDestination
    project_uid: NotRequired[str]


def parse_notification_event(body: bytes, headers: Mapping[str, str], secret: str, *,
                             expected_app_key: str, expected_connection_uid: str,
                             now: int | None = None) -> NotificationEvent:
    """Verify exact bytes and context before parsing. Recheck host authority before I/O."""
    verify_webhook(body, headers, secret, now=now)
    _segment(expected_app_key)
    _uid(expected_connection_uid)
    try:
        event = json.loads(body)
        if not isinstance(event, dict) or type(event["schema_version"]) is not int or event["schema_version"] != 1:
            raise ValueError
        if (event["event_type"] != "io.langboard.notification.requested.v1"
                or event["app_key"] != expected_app_key or event["connection_uid"] != expected_connection_uid):
            raise ValueError
        _uid(event["event_uid"])
        fence = event["notification_fence"]
        for key in ("event_revision", "subscription_generation", "destination_revision"):
            _positive(fence[key])
        if fence["event_revision"] != 1:
            raise ValueError
        for key in ("subscription_uid", "destination_uid"):
            _uid(fence[key])
        dest = event["destination"]
        _uid(dest["destination_uid"])
        _positive(dest["revision"])
        external = event["external_destination"]
        if external["kind"] not in ("personal", "shared") or not isinstance(external["external_id"], str) or not external["external_id"]:
            raise ValueError
        if not isinstance(event["expires_at"], str) or not event["expires_at"]:
            raise ValueError
        datetime.fromisoformat(event["expires_at"])
        notification = event["notification"]
        for key, limit in (("title", 120), ("body", 2000)):
            if not isinstance(notification[key], str) or not notification[key] or len(notification[key]) > limit:
                raise ValueError
        kind = notification["kind"]
        if "project_uid" in event:
            if kind != "missed_summary" or external["kind"] != "shared":
                raise ValueError
            _uid(event["project_uid"])
        if external["kind"] == "shared" and kind not in ("test", "card_deadline", "missed_summary"):
            raise ValueError
        if kind in ("card_activity", "card_deadline", "card_reminder"):
            if not isinstance(notification["url"], str) or not notification["url"]:
                raise ValueError
            url = urlsplit(notification["url"])
            if (url.scheme not in ("http", "https") or not url.hostname or url.username or url.password
                    or len(notification["url"]) > 2048):
                raise ValueError
            source = notification["source"]
            for key in ("notification_uid", "project_uid", "card_uid"):
                _uid(source[key])
            source_type = source["type"]
            if kind == "card_deadline":
                if source_type != "scheduled_rule" or not isinstance(notification["deadline_at"], str) or not notification["deadline_at"]:
                    raise ValueError
                datetime.fromisoformat(notification["deadline_at"])
                _uid(source["rule_uid"])
            elif kind == "card_reminder":
                if source_type != "card_reminder":
                    raise ValueError
                _uid(source["rule_uid"])
                _uid(source["occurrence_uid"])
            elif source_type not in ("assigned_to_card", "mentioned_in_card", "mentioned_in_comment", "card_comment_added", "card_moved"):
                raise ValueError
            if source_type in ("mentioned_in_comment", "card_comment_added"):
                _uid(source["comment_uid"])
            actor = notification["actor"]
            if actor["kind"] not in ("user", "bot"):
                raise ValueError
            _uid(actor["uid"])
            if not isinstance(notification["reasons"], list) or any(not isinstance(x, str) or not x for x in notification["reasons"]):
                raise ValueError
        elif kind == "missed_summary":
            if set(notification) != {"kind", "title", "body", "count", "window_start", "window_end"}:
                raise ValueError
            if type(notification["count"]) is not int or not 1 <= notification["count"] <= 50:
                raise ValueError
            start = datetime.fromisoformat(notification["window_start"])
            end = datetime.fromisoformat(notification["window_end"])
            expiry = datetime.fromisoformat(event["expires_at"])
            if (start.utcoffset() != timedelta(0) or end.utcoffset() != timedelta(0)
                    or not start <= end < expiry):
                raise ValueError
        elif kind != "test":
            raise ValueError
        return cast(NotificationEvent, event)
    except (ValueError, TypeError, KeyError, UnicodeDecodeError, AttributeError):
        raise ValueError("Invalid native notification event") from None
