"""App-owned card creation and content. Receipts do not authorize execution."""

import re
from hashlib import sha256
from json import dumps
from typing import Literal, TypedDict, cast
from .client import MutationOutcomeUnknown
from .resources import _uid
from .rest import ApiTransport


class AppCardCreationReceipt(TypedDict):
    card_uid: str
    receipt_uid: str
    created: bool
    effects_state: Literal["pending", "dispatched", "failed"]


def _creation_body(resource_uid, external_id, title, description, card_type, presentation):
    _uid(resource_uid)
    for value, maximum in ((external_id, 200), (title, 200), (description, 100000)):
        if not isinstance(value, str) or len(value) > maximum:
            raise ValueError("Invalid app card text")
    if not external_id or not title:
        raise ValueError("External identity and title are required")
    if card_type is not None and (not isinstance(card_type, str) or not re.fullmatch(r"[a-z][a-z0-9_-]{0,63}", card_type)):
        raise ValueError("Invalid app card type")
    if presentation is not None and not isinstance(presentation, dict):
        raise ValueError("App card presentation must be an object")
    body: dict = {"resource_uid": resource_uid, "external_id": external_id, "title": title, "description": description}
    if card_type is not None:
        body["card_type"] = card_type
    if presentation is not None:
        body["presentation"] = presentation
    return body


class AppCardAttachmentReceipt(TypedDict):
    schema_version: int
    app_key: str
    connection_uid: str
    card_uid: str
    attachment_uid: str
    file_key: str
    filename: str
    sha256: str
    byte_size: int
    revision: str
    available: bool


def _attachment_path(board_uid, card_uid, file_key):
    board_uid, card_uid = _uid(board_uid), _uid(card_uid)
    if not isinstance(file_key, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._:-]{0,127}", file_key):
        raise ValueError("Invalid attachment file key")
    return f"/apps/v1/boards/{board_uid}/cards/{card_uid}/attachments/{file_key}"


def _attachment_receipt(receipt, card_uid, file_key, content_sha256, byte_size) -> AppCardAttachmentReceipt:
    _uid(receipt["attachment_uid"])
    _uid(receipt["connection_uid"])
    if (
        type(receipt["schema_version"]) is not int or receipt["schema_version"] != 1
        or receipt["card_uid"] != card_uid or receipt["file_key"] != file_key
        or receipt["sha256"] != content_sha256 or type(receipt["byte_size"]) is not int
        or receipt["byte_size"] != byte_size or type(receipt["available"]) is not bool
        or not isinstance(receipt["app_key"], str) or not receipt["app_key"]
        or not isinstance(receipt["filename"], str) or not receipt["filename"]
        or not re.fullmatch(r"[0-9a-f]{64}", receipt["revision"])
    ):
        raise ValueError("Invalid app attachment receipt")
    return cast(AppCardAttachmentReceipt, receipt)


class AppCards:
    def __init__(self, transport: ApiTransport):
        self.transport = transport

    async def create(self, board_uid: str, *, resource_uid: str, external_id: str, title: str,
                     description: str = "", card_type: str | None = None,
                     presentation: dict | None = None) -> AppCardCreationReceipt:
        """Create through app authority once; preserve source identity on an unknown outcome.

        The host owns Backlog selection, current authority and identical replay.
        This method never retries. Reconcile a lost response with read_creation_receipt
        using the same source identity and original creation payload.
        """
        board_uid = _uid(board_uid)
        body = _creation_body(resource_uid, external_id, title, description, card_type, presentation)
        result = await self.transport.request("POST", f"/apps/v1/boards/{board_uid}/cards", json=body)
        try:
            _uid(result["card_uid"])
            _uid(result["receipt_uid"])
            if type(result["created"]) is not bool or result["effects_state"] not in ("pending", "dispatched", "failed"):
                raise ValueError("Invalid creation receipt")
        except (KeyError, TypeError, ValueError):
            raise MutationOutcomeUnknown(
                "App card creation receipt unavailable; retain the original source identity and payload before reconciliation"
            ) from None
        return cast(AppCardCreationReceipt, result)

    async def read_creation_receipt(self, board_uid: str, *, resource_uid: str, external_id: str,
                                    title: str, description: str = "", card_type: str | None = None,
                                    presentation: dict | None = None) -> dict:
        """Read one source receipt using the exact original create arguments; never POST.

        A missing receipt is a point-in-time observation, not permission to retry.
        HTTP 403/409 and transport errors propagate; none means a missing receipt.
        """
        board_uid = _uid(board_uid)
        _creation_body(resource_uid, external_id, title, description, card_type, presentation)
        fingerprint = sha256(dumps(
            [title, description, presentation, card_type] if card_type is not None
            else [title, description, presentation], sort_keys=True, ensure_ascii=False,
        ).encode()).hexdigest()
        result = await self.transport.request("GET", f"/apps/v1/boards/{board_uid}/card-creation-receipt", params={
            "resource_uid": resource_uid, "external_id": external_id, "payload_fingerprint": fingerprint,
        })
        try:
            if type(result["found"]) is not bool:
                raise ValueError()
            if result["found"]:
                receipt = result["receipt"]
                _uid(receipt["card_uid"])
                _uid(receipt["receipt_uid"])
                if (receipt["created"] is not False
                        or receipt["effects_state"] not in ("pending", "dispatched", "failed")
                        or result["payload_fingerprint"] != fingerprint):
                    raise ValueError()
            elif set(result) != {"found"}:
                raise ValueError()
        except (KeyError, TypeError, ValueError):
            raise RuntimeError("App card creation lookup returned an invalid receipt; reconciliation remains unknown") from None
        return result

    async def upload_attachment(self, board_uid: str, card_uid: str, *, file_key: str,
                                filename: str, content: bytes) -> AppCardAttachmentReceipt:
        """Send one file under app authority. Reconcile an unknown outcome before another write."""
        path = _attachment_path(board_uid, card_uid, file_key)
        if (not isinstance(filename, str) or not 1 <= len(filename) <= 255 or filename in {".", ".."}
                or "/" in filename or chr(92) in filename or any(ord(char) < 32 for char in filename)):
            raise ValueError("Invalid attachment filename")
        if not isinstance(content, bytes) or not content:
            raise ValueError("Attachment bytes are required")
        digest = sha256(content).hexdigest()
        result = await self.transport.request(
            "POST", path,
            data={"sha256": digest, "byte_size": str(len(content))},
            files={"attachment": (filename, content, "application/octet-stream")},
        )
        try:
            if type(result["created"]) is not bool:
                raise ValueError()
            receipt = _attachment_receipt(result["receipt"], card_uid, file_key, digest, len(content))
            if receipt["filename"] != filename or (result["created"] and not receipt["available"]):
                raise ValueError()
            return receipt
        except (KeyError, TypeError, ValueError):
            raise MutationOutcomeUnknown(
                "App attachment receipt unavailable; retain the original file key and bytes for reconciliation"
            ) from None

    async def read_attachment_receipt(self, board_uid: str, card_uid: str, *, file_key: str,
                                      content_sha256: str, byte_size: int) -> AppCardAttachmentReceipt | None:
        """Verify the recorded bytes and current availability without uploading again."""
        path = _attachment_path(board_uid, card_uid, file_key)
        if not isinstance(content_sha256, str) or not re.fullmatch(r"[0-9a-f]{64}", content_sha256):
            raise ValueError("Invalid expected SHA-256")
        if type(byte_size) is not int or byte_size < 1:
            raise ValueError("A positive expected byte size is required")
        result = await self.transport.request("GET", path)
        try:
            if result["found"] is False and result["receipt"] is None:
                return None
            if result["found"] is not True:
                raise ValueError()
            return _attachment_receipt(result["receipt"], card_uid, file_key, content_sha256, byte_size)
        except (KeyError, TypeError, ValueError):
            raise RuntimeError("App attachment lookup returned an invalid receipt; reconciliation remains unknown") from None

    async def read(self, board_uid: str, card_uid: str, *, offset: int = 0, limit: int = 16000) -> dict:
        board_uid, card_uid = _uid(board_uid), _uid(card_uid)
        if type(offset) is not int or offset < 0 or type(limit) is not int or not 1 <= limit <= 16000:
            raise ValueError("Invalid card content window")
        return await self.transport.request("GET", f"/apps/v1/boards/{board_uid}/cards/{card_uid}",
                                            params={"offset": offset, "limit": limit})

    async def read_archive_outcome(self, board_uid: str, archive_uid: str) -> dict:
        """Read a current owning-app receipt; no provider mutation or delivery retry."""
        board_uid, archive_uid = _uid(board_uid), _uid(archive_uid)
        return await self.transport.request("GET", f"/apps/v1/boards/{board_uid}/archives/{archive_uid}")

    async def report_archive_outcome(self, board_uid: str, archive_uid: str, *, expected_revision: int,
                                     state: str, external_state: str | None, readback_confirmed: bool) -> dict:
        """Report a provider outcome using a connection credential, without executing or retrying it.

        Keep the original revision and outcome on an ambiguous retry. Successful
        transport is not proof of an external change; applied states require readback.
        """
        board_uid, archive_uid = _uid(board_uid), _uid(archive_uid)
        if type(expected_revision) is not int or expected_revision < 0:
            raise ValueError("A nonnegative outcome revision is required")
        if state not in ("applied", "already_applied", "failed", "blocked", "unknown") or type(readback_confirmed) is not bool:
            raise ValueError("Invalid archive outcome")
        if external_state is not None and (not isinstance(external_state, str) or not external_state.strip() or len(external_state) > 64):
            raise ValueError("Invalid provider state")
        if state in ("applied", "already_applied") and (not readback_confirmed or not external_state):
            raise ValueError("Applied outcomes require provider state readback")
        return await self.transport.request("POST", f"/apps/v1/boards/{board_uid}/archives/{archive_uid}/outcome", json={
            "expected_revision": expected_revision,
            "outcome": {"state": state, "external_state": external_state, "readback_confirmed": readback_confirmed},
        })
