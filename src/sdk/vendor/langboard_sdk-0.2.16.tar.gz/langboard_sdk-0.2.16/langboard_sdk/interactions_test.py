import unittest
from unittest.mock import AsyncMock
from .interactions import AppCardInteractions, validate_card_interaction

BASE = {
    "schema_version": 1,
    "kind": "question",
    "app_request_key": "deploy-choice",
    "prompt": {"en": "Choose", "ko": "선택"},
    "questions": [
        {
            "id": "action",
            "prompt": {"en": "Action"},
            "type": "single_choice",
            "choices": [
                {"id": "review", "label": {"en": "Review"}},
                {"id": "retry", "label": {"en": "Retry"}},
            ],
        }
    ],
    "presentation": {"type": "choice_card"},
    "outcomes": {"review": {"workflow_stage": "review"}},
    "expires_at": "2026-10-12T00:00:00+00:00",
}


class InteractionTests(unittest.TestCase):
    def test_valid_and_non_mutating(self):
        item = validate_card_interaction(BASE)
        self.assertEqual(item["questions"][0]["choices"][0]["id"], "review")
        self.assertEqual(BASE["presentation"]["type"], "choice_card")

    def test_approval_requires_explicit_choices(self):
        item = {
            **BASE,
            "kind": "approval",
            "outcomes": {},
            "questions": [
                {
                    **BASE["questions"][0],
                    "choices": [
                        {"id": "approve", "label": {"en": "Approve"}},
                        {"id": "reject", "label": {"en": "Reject"}},
                    ],
                }
            ],
        }
        self.assertEqual(validate_card_interaction(item)["kind"], "approval")

    def test_reaction_requires_current_comment_mapping(self):
        item = {
            **BASE,
            "presentation": {
                "type": "comment_reaction",
                "comment_uid": "A" * 11,
                "reactions": {"thumbs-up": "review", "thumbs-down": "retry"},
            },
        }
        self.assertEqual(
            validate_card_interaction(item)["presentation"]["type"], "comment_reaction"
        )

    def test_rejects_label_as_identity_and_expired_missing_timezone(self):
        item = {
            **BASE,
            "questions": [
                {
                    **BASE["questions"][0],
                    "choices": [{"id": "Review", "label": {"en": "Review"}}],
                }
            ],
        }
        with self.assertRaises(ValueError):
            validate_card_interaction(item)
        with self.assertRaises(ValueError):
            validate_card_interaction({**BASE, "expires_at": "2026-10-12T00:00:00"})

    def test_rejects_unknown_stage_and_reaction(self):
        with self.assertRaises(ValueError):
            validate_card_interaction(
                {**BASE, "outcomes": {"review": {"workflow_stage": "unknown"}}}
            )
        with self.assertRaises(ValueError):
            validate_card_interaction(
                {
                    **BASE,
                    "presentation": {
                        "type": "comment_reaction",
                        "comment_uid": "A" * 11,
                        "reactions": {"rocket": "review"},
                    },
                }
            )


class InteractionTransportTests(unittest.IsolatedAsyncioTestCase):
    async def test_cancel_preserves_revision_and_server_receipt(self):
        transport = AsyncMock()
        receipt = {"state": "cancelled", "revision": 2, "changed": False,
                   "execution_resumed": False}
        transport.request.return_value = receipt
        api = AppCardInteractions(transport)
        result = await api.cancel("A" * 11, "B" * 11, "C" * 11, expected_revision=1)
        self.assertIs(result, receipt)
        transport.request.assert_awaited_once_with(
            "POST", f"/apps/v1/boards/{'A' * 11}/cards/{'B' * 11}/interactions/{'C' * 11}/cancel",
            json={"expected_revision": 1},
        )

    async def test_cancel_invalid_inputs_make_no_request(self):
        transport = AsyncMock()
        api = AppCardInteractions(transport)
        for revision in (True, False, 0, -1, 1.0, "1", None):
            with self.subTest(revision=revision), self.assertRaises(ValueError):
                await api.cancel("A" * 11, "B" * 11, "C" * 11, expected_revision=revision)
        for uids in (("bad", "B" * 11, "C" * 11),
                     ("A" * 11, "bad", "C" * 11),
                     ("A" * 11, "B" * 11, "../cancel")):
            with self.subTest(uids=uids), self.assertRaises(ValueError):
                await api.cancel(*uids, expected_revision=1)
        transport.request.assert_not_awaited()


if __name__ == "__main__":
    unittest.main()
