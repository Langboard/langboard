"""Bounded app-card choices; display never grants external action or runtime authority."""

import json
import re
from .workflow import WorkflowStage


def _identifier(value):
    if not isinstance(value, str) or not re.fullmatch(r"[a-z][a-z0-9_-]{0,63}", value):
        raise ValueError("Invalid interaction identifier")


def _localized(value, limit):
    if not isinstance(value, dict) or not 1 <= len(value) <= 16 or "en" not in value:
        raise ValueError("Interaction text requires English fallback")
    for locale, text in value.items():
        if (
            not isinstance(locale, str)
            or not re.fullmatch(r"[a-z]{2,3}(-[A-Za-z0-9]{2,8}){0,2}", locale)
            or not isinstance(text, str)
            or not text.strip()
            or len(text) > limit
        ):
            raise ValueError("Invalid interaction localized text")


def validate_card_interaction(item: dict) -> dict:
    """Validate an app-owned request body, without interpreting it as permission."""
    fields = {
        "schema_version",
        "kind",
        "app_request_key",
        "prompt",
        "questions",
        "presentation",
        "outcomes",
        "expires_at",
        "execution",
    }
    if not isinstance(item, dict) or set(item) - fields:
        raise ValueError("Invalid interaction fields")
    try:
        frozen = json.loads(json.dumps(item, allow_nan=False))
    except (ValueError, TypeError):
        raise ValueError("Interaction must be JSON") from None
    item = frozen
    if len(json.dumps(frozen).encode()) > 32768:
        raise ValueError("Interaction exceeds 32 KiB")
    if type(item.get("schema_version")) is not int or item["schema_version"] != 1:
        raise ValueError("Unsupported interaction schema")
    if item.get("kind") not in ("approval", "question", "action"):
        raise ValueError("Invalid interaction kind")
    _identifier(item.get("app_request_key"))
    _localized(item.get("prompt"), 4096)
    questions = item.get("questions")
    if not isinstance(questions, list) or not 1 <= len(questions) <= 20:
        raise ValueError("Interaction needs 1 to 20 questions")
    question_ids = set()
    for q in questions:
        if not isinstance(q, dict) or set(q) - {
            "id",
            "prompt",
            "type",
            "choices",
            "min_selections",
            "max_selections",
            "max_length",
        }:
            raise ValueError("Invalid question fields")
        _identifier(q.get("id"))
        if q["id"] in question_ids:
            raise ValueError("Duplicate question identifier")
        question_ids.add(q["id"])
        _localized(q.get("prompt"), 4096)
        kind = q.get("type")
        if kind == "free_text":
            if (
                set(q) != {"id", "prompt", "type", "max_length"}
                or type(q["max_length"]) is not int
                or not 1 <= q["max_length"] <= 16000
            ):
                raise ValueError("Invalid free text limits")
        elif kind in ("single_choice", "multi_choice", "choice_or_text"):
            allowed = {"id", "prompt", "type", "choices"} | (
                {"min_selections", "max_selections"}
                if kind == "multi_choice"
                else {"max_length"} if kind == "choice_or_text" else set()
            )
            if set(q) != allowed:
                raise ValueError("Invalid choice fields")
            if kind == "choice_or_text" and (
                item["kind"] != "question"
                or type(q["max_length"]) is not int
                or not 1 <= q["max_length"] <= 16000
            ):
                raise ValueError("Choice or text requires a question with bounded text")
            choices = q["choices"]
            if not isinstance(choices, list) or not 1 <= len(choices) <= 20:
                raise ValueError("Choices must be bounded")
            ids = set()
            for choice in choices:
                if not isinstance(choice, dict) or set(choice) - {
                    "id",
                    "label",
                    "description",
                }:
                    raise ValueError("Invalid choice fields")
                _identifier(choice.get("id"))
                if choice["id"] in ids:
                    raise ValueError("Duplicate choice identifier")
                ids.add(choice["id"])
                _localized(choice.get("label"), 256)
                if "description" in choice:
                    _localized(choice["description"], 2048)
            if kind == "multi_choice" and (
                type(q["min_selections"]) is not int
                or type(q["max_selections"]) is not int
                or not 0 <= q["min_selections"] <= q["max_selections"] <= len(choices)
                or q["max_selections"] == 0
            ):
                raise ValueError("Invalid selection limits")
        else:
            raise ValueError("Invalid question type")
    if item["kind"] == "approval" and (
        len(questions) != 1
        or questions[0]["type"] != "single_choice"
        or {c["id"] for c in questions[0]["choices"]} != {"approve", "reject"}
    ):
        raise ValueError("Approval requires approve and reject choices")
    presentation = item.get("presentation")
    if not isinstance(presentation, dict) or presentation.get("type") not in (
        "choice_card",
        "card_action",
        "comment_reaction",
    ):
        raise ValueError("Invalid interaction presentation")
    if presentation["type"] == "comment_reaction":
        if (
            set(presentation) != {"type", "comment_uid", "reactions"}
            or not isinstance(presentation["comment_uid"], str)
            or not re.fullmatch(r"[A-Za-z0-9]{11}", presentation["comment_uid"])
        ):
            raise ValueError("Invalid reaction comment")
        reactions = presentation["reactions"]
        allowed = {
            "check-mark",
            "confusing",
            "eyes",
            "heart",
            "laughing",
            "party-popper",
            "rocket",
            "thumbs-down",
            "thumbs-up",
        }
        if (
            len(questions) != 1
            or questions[0]["type"] != "single_choice"
            or not isinstance(reactions, dict)
            or not reactions
            or set(reactions) - allowed
            or any(not isinstance(v, str) for v in reactions.values())
            or set(reactions.values()) != {c["id"] for c in questions[0]["choices"]}
        ):
            raise ValueError("Reactions must map to the current single choice")
    elif set(presentation) != {"type"}:
        raise ValueError("Invalid presentation fields")
    outcomes = item.get("outcomes", {})
    if not isinstance(outcomes, dict):
        raise ValueError("Invalid outcomes")
    if outcomes:
        if (
            len(questions) != 1
            or questions[0]["type"] not in ("single_choice", "choice_or_text")
            or set(outcomes) - {c["id"] for c in questions[0]["choices"]}
        ):
            raise ValueError("Workflow outcomes require one choice question")
        for outcome in outcomes.values():
            if not isinstance(outcome, dict) or set(outcome) != {"workflow_stage"}:
                raise ValueError("Invalid workflow outcome")
            WorkflowStage(outcome["workflow_stage"])
    if "execution" in item:
        execution = item["execution"]
        if (
            not isinstance(execution, dict)
            or set(execution) != {"request_uid", "generation"}
            or not isinstance(execution["request_uid"], str)
            or not re.fullmatch(r"[A-Za-z0-9]{11}", execution["request_uid"])
            or type(execution["generation"]) is not int
            or execution["generation"] < 1
        ):
            raise ValueError("Invalid interaction execution context")
    from datetime import datetime

    try:
        expiry = datetime.fromisoformat(item["expires_at"])
    except (ValueError, TypeError, KeyError):
        raise ValueError("Interaction requires explicit expiry") from None
    if expiry.tzinfo is None:
        raise ValueError("Interaction expiry requires timezone")
    return frozen


class AppCardInteractions:
    """Current app-owned request storage; no implicit response or execution."""

    def __init__(self, transport):
        self._transport = transport

    @staticmethod
    def _path(board_uid, card_uid):
        for uid in (board_uid, card_uid):
            if not isinstance(uid, str) or not re.fullmatch(r"[A-Za-z0-9]{11}", uid):
                raise ValueError("Invalid board or card UID")
        return f"/apps/v1/boards/{board_uid}/cards/{card_uid}/interactions"

    async def create(self, board_uid, card_uid, request):
        path = self._path(board_uid, card_uid)
        return await self._transport.request(
            "POST", path, json={"request": validate_card_interaction(request)}
        )

    @classmethod
    def _interaction_path(cls, board_uid, card_uid, interaction_uid):
        path = cls._path(board_uid, card_uid)
        if not isinstance(interaction_uid, str) or not re.fullmatch(
            r"[A-Za-z0-9]{11}", interaction_uid
        ):
            raise ValueError("Invalid interaction UID")
        return f"{path}/{interaction_uid}"

    async def read(self, board_uid, card_uid, interaction_uid):
        path = self._interaction_path(board_uid, card_uid, interaction_uid)
        return await self._transport.request("GET", path)

    async def cancel(self, board_uid, card_uid, interaction_uid, *, expected_revision):
        """Cancel request storage only; preserve the original revision on retry."""
        path = self._interaction_path(board_uid, card_uid, interaction_uid)
        if type(expected_revision) is not int or expected_revision < 1:
            raise ValueError("A positive interaction revision is required")
        return await self._transport.request(
            "POST", f"{path}/cancel", json={"expected_revision": expected_revision}
        )


def validate_card_interaction_values(request: dict, values: dict) -> dict:
    """Validate human values against the immutable request, without authorizing them."""
    request = validate_card_interaction(request)
    if not isinstance(values, dict):
        raise ValueError("Interaction values must be keyed by question ID")
    try:
        frozen = json.loads(json.dumps(values, allow_nan=False))
    except (ValueError, TypeError):
        raise ValueError("Interaction values must be JSON") from None
    if len(json.dumps(frozen).encode()) > 32768:
        raise ValueError("Interaction values exceed 32 KiB")
    questions = request["questions"]
    if set(frozen) != {q["id"] for q in questions}:
        raise ValueError("Every declared question requires exactly one answer")
    for question in questions:
        value = frozen[question["id"]]
        if not isinstance(value, dict):
            raise ValueError("Invalid interaction answer")
        kind = question["type"]
        if kind == "free_text" or (kind == "choice_or_text" and set(value) == {"text"}):
            text = value.get("text")
            if (set(value) != {"text"} or not isinstance(text, str)
                or not text.strip() or len(text) > question["max_length"]):
                raise ValueError("Invalid interaction text")
        elif kind in ("single_choice", "choice_or_text"):
            if set(value) != {"choice_id"} or not isinstance(value["choice_id"], str):
                raise ValueError("Exactly one choice ID or text answer is required")
            if value["choice_id"] not in {choice["id"] for choice in question["choices"]}:
                raise ValueError("Answer references an undeclared choice")
        else:
            choices = value.get("choice_ids")
            if (set(value) != {"choice_ids"} or not isinstance(choices, list)
                or any(not isinstance(choice, str) for choice in choices)
                or len(set(choices)) != len(choices)
                or not question["min_selections"] <= len(choices) <= question["max_selections"]
                or set(choices) - {choice["id"] for choice in question["choices"]}):
                raise ValueError("Invalid multiple choice answer")
    return frozen
