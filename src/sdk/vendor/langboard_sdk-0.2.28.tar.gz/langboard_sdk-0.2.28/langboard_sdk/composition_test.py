"""Composition calls retain explicit authority snapshots and uncertain outcomes."""
from types import SimpleNamespace
from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock
from . import AppManager, AppRegistry, MutationOutcomeUnknown


class CompositionTests(IsolatedAsyncioTestCase):
    async def test_missing_discovery_does_not_infer_groups(self):
        transport = SimpleNamespace(request=AsyncMock(return_value={"apps": []}))
        with self.assertRaises(RuntimeError):
            await AppRegistry(transport).compositions()
        with self.assertRaises(RuntimeError):
            await AppManager(transport, "board").compositions()

    async def test_reviewed_group_members_and_revisions(self):
        group = {"key": "tools", "module_keys": ["github", "monitor"], "revision": "a" * 64}
        transport = SimpleNamespace(request=AsyncMock(return_value={"composition": group}))
        registry = AppRegistry(transport)
        self.assertEqual(await registry.save_composition("tools", "Tools", "Reviewed modules", group["module_keys"]), group)
        transport.request.assert_awaited_once_with("POST", "/settings/apps/compositions", json={
            "key": "tools", "name": "Tools", "description": "Reviewed modules", "module_keys": group["module_keys"],
            "expected_revision": None,
        })
        transport.request.reset_mock()
        for keys in ([], ["github", "github"], ["../monitor"], [True]):
            with self.assertRaises(ValueError):
                await registry.save_composition("tools", "Tools", "Reviewed modules", keys)
        transport.request.assert_not_awaited()
        transport.request.return_value = {"key": "tools", "ungrouped": True}
        await registry.ungroup_composition("tools", group["revision"])
        transport.request.assert_awaited_once_with("POST", "/settings/apps/compositions/tools/ungroup",
                                                 json={"expected_revision": "a" * 64})

    async def test_withdrawal_uses_null_for_unbound_and_requires_complete_receipt(self):
        transport = SimpleNamespace(request=AsyncMock(return_value={"key": "tools", "disabled": True,
                                                                   "module_keys": ["monitor", "github"]}))
        manager = AppManager(transport, "board")
        revisions = {"github": "b" * 64, "monitor": None}
        await manager.disable_composition("tools", "a" * 64, revisions)
        transport.request.assert_awaited_once_with("POST", "/board/board/settings/apps/compositions/tools/disable",
            json={"expected_revision": "a" * 64, "binding_revisions": revisions})
        transport.request.reset_mock()
        for targets in ({}, {"github": "stale"}, {"../monitor": None}, {"monitor": False}):
            with self.assertRaises(ValueError):
                await manager.disable_composition("tools", "a" * 64, targets)
        transport.request.assert_not_awaited()
        for result in ({}, {"key": "tools", "disabled": True, "module_keys": ["github"]}):
            transport.request.return_value = result
            with self.assertRaises(MutationOutcomeUnknown):
                await manager.disable_composition("tools", "a" * 64, revisions)
        self.assertEqual(transport.request.await_count, 2)

    async def test_unknown_group_mutation_receipts_never_replay(self):
        transport = SimpleNamespace(request=AsyncMock(return_value={}))
        with self.assertRaises(MutationOutcomeUnknown):
            await AppRegistry(transport).save_composition("tools", "Tools", "Reviewed", ["github"])
        transport.request.assert_awaited_once()
        transport.request.reset_mock()
        with self.assertRaises(MutationOutcomeUnknown):
            await AppRegistry(transport).ungroup_composition("tools", "a" * 64)
        transport.request.assert_awaited_once()
