from types import SimpleNamespace
from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock
from . import AppCards, AppManager, validate_app_definition


class CardReadTests(IsolatedAsyncioTestCase):
    async def test_archive_reconciliation_read_validates_both_identities(self):
        transport = SimpleNamespace(request=AsyncMock(return_value={"receipt": {"outcome_revision": 1}}))
        result = await AppCards(transport).read_archive_outcome("board000001", "archiv00001")
        self.assertEqual(result["receipt"]["outcome_revision"], 1)
        transport.request.assert_awaited_once_with("GET", "/apps/v1/boards/board000001/archives/archiv00001")
        transport.request.reset_mock()
        for board, archive in (("../board", "archiv00001"), ("board000001", "bad")):
            with self.assertRaises(ValueError):
                await AppCards(transport).read_archive_outcome(board, archive)
        transport.request.assert_not_awaited()

    async def test_archive_outcome_and_explicit_opt_in_are_separate(self):
        transport = SimpleNamespace(request=AsyncMock(return_value={"changed": True}))
        await AppCards(transport).report_archive_outcome("board000001", "archiv00001", expected_revision=0,
                                                       state="applied", external_state="closed", readback_confirmed=True)
        transport.request.assert_awaited_once_with("POST", "/apps/v1/boards/board000001/archives/archiv00001/outcome",
            json={"expected_revision": 0, "outcome": {"state": "applied", "external_state": "closed", "readback_confirmed": True}})
        transport.request.reset_mock()
        await AppManager(transport, "board000001").set_archive_sync("example", "a" * 64, [])
        transport.request.assert_awaited_once_with("PUT", "/board/board000001/apps/example/archive-sync",
                                                 json={"expected_revision": "a" * 64, "card_types": []})

    async def test_invalid_archive_outcomes_never_send_or_retry(self):
        transport = SimpleNamespace(request=AsyncMock())
        base = dict(expected_revision=0, state="applied", external_state="closed", readback_confirmed=True)
        for change in ({"expected_revision": True}, {"expected_revision": -1}, {"state": "delivered"},
                       {"external_state": ""}, {"external_state": "x" * 65}, {"external_state": None},
                       {"readback_confirmed": False}, {"readback_confirmed": 1}):
            with self.assertRaises(ValueError):
                await AppCards(transport).report_archive_outcome("board000001", "archiv00001", **(base | change))
        transport.request.assert_not_awaited()
        transport.request.side_effect = TimeoutError()
        with self.assertRaises(TimeoutError):
            await AppCards(transport).report_archive_outcome("board000001", "archiv00001", **base)
        self.assertEqual(transport.request.await_count, 1)

    async def test_bounded_current_read_and_explicit_capability(self):
        transport = SimpleNamespace(request=AsyncMock(return_value={"card_revision": 7}))
        receipt = await AppCards(transport).read("board000001", "card0000001", offset=10, limit=20)
        self.assertEqual(receipt, {"card_revision": 7})
        transport.request.assert_awaited_once_with("GET", "/apps/v1/boards/board000001/cards/card0000001",
                                                  params={"offset": 10, "limit": 20})
        transport.request.reset_mock()
        for kwargs in ({"offset": True}, {"offset": -1}, {"limit": 0}, {"limit": 16001}):
            with self.assertRaises(ValueError):
                await AppCards(transport).read("board000001", "card0000001", **kwargs)
        transport.request.assert_not_awaited()
        declaration = {"schema_version": 2, "key": "example", "version": "1.0.0",
                       "name": "Example", "description": "Read current owned work",
                       "resource_types": ["issue"], "capabilities": ["cards.read"]}
        self.assertEqual(validate_app_definition(declaration)["capabilities"], ["cards.read"])
