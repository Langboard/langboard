"""Portable declaration validation and ambiguous mutation behavior."""

from types import SimpleNamespace
from unittest import IsolatedAsyncioTestCase, main
from unittest.mock import AsyncMock
from .client import MutationOutcomeUnknown
from .definition import validate_app_definition
from .registry import AppRegistry


DECLARATION = {
    "schema_version": 1, "key": "example-erp", "version": "1.0.0", "name": "Example ERP",
    "description": "External issues.", "capabilities": ["cards.create"], "resource_types": ["issue"],
    "workflow_requirements": {"required": ["backlog"], "optional": []},
    "panel": {"url": "https://example.invalid/panel", "name": "ERP", "icon": "📋"},
}


class RegistryTests(IsolatedAsyncioTestCase):
    async def test_declaration_does_not_create_arbitrary_stages_or_authority(self):
        self.assertEqual(validate_app_definition(DECLARATION), DECLARATION)
        transport = SimpleNamespace(request=AsyncMock())
        registry = AppRegistry(transport)
        for change in [{"schema_version": True}, {"version": "latest"}, {"granted_capabilities": ["*"]},
                       {"capabilities": ["*"]}, {"workflow_requirements": {"required": ["erp-custom"], "optional": []}},
                       {"panel": {"url": "https://secret@example.invalid", "name": "ERP", "icon": "📋"}},
                       {"panel": {"url": "javascript:alert(1)", "name": "ERP", "icon": "📋"}}]:
            with self.assertRaises(ValueError):
                await registry.approve({**DECLARATION, **change})
        transport.request.assert_not_awaited()

    async def test_signal_sources_are_explicit_and_bounded(self):
        from .governance import update_consent
        old = {**DECLARATION, "capabilities": ["panels.render", "signals.read"], "signal_sources": ["example-adapter"]}
        self.assertEqual(validate_app_definition(old), old)
        for sources in ([], ["*"], ["example-adapter", "example-adapter"], "example-adapter", [True], ["x"] * 17):
            with self.assertRaises(ValueError):
                validate_app_definition({**old, "signal_sources": sources})
        with self.assertRaises(ValueError):
            validate_app_definition({**old, "capabilities": ["panels.render"]})
        new = {**old, "signal_sources": ["example-adapter", "another-adapter"]}
        decision = update_consent(old, new, old["capabilities"])
        self.assertEqual(decision["retained"], {"panels.render"})
        self.assertEqual(decision["newly_requested"], {"signals.read"})
        self.assertFalse(decision["trust_changed"])
        self.assertEqual(update_consent(new, {**new, "signal_sources": list(reversed(new["signal_sources"]))}, new["capabilities"])["retained"], set(new["capabilities"]))

    async def test_registration_receipt_is_required_and_never_replayed(self):
        transport = SimpleNamespace(request=AsyncMock(return_value={"app": {}}))
        with self.assertRaises(MutationOutcomeUnknown):
            await AppRegistry(transport).approve(DECLARATION)
        transport.request.assert_awaited_once()


if __name__ == "__main__":
    main()
