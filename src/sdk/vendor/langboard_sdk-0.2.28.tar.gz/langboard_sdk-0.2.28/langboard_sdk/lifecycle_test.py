from copy import deepcopy
from unittest import TestCase
from .definition import validate_app_definition
from .lifecycle import validate_card_lifecycle
from .card_interactions import validate_card_interactions
from .registry_test import DECLARATION


class LifecycleTests(TestCase):
    def test_new_card_producer_requires_archive_policy(self):
        with self.assertRaisesRegex(ValueError, "lifecycle"):
            validate_app_definition({**DECLARATION, "schema_version": 2})
        # Existing approved definitions remain readable during explicit migration.
        self.assertEqual(validate_app_definition(DECLARATION), DECLARATION)

    def test_external_and_retained_card_types_are_explicit(self):
        value = {
            "issue": {"archive": {"mode": "external", "action": "close_issue", "default_enabled": False, "description": "Close the linked issue."}, "restore": "retain_external_state"},
            "deployment": {"archive": {"mode": "retain", "description": "Keep deployment history; do not stop a service."}, "restore": "retain_external_state"},
        }
        saved = deepcopy(value)
        result = validate_card_lifecycle(value)
        result["issue"]["archive"]["action"] = "changed"
        self.assertEqual(value, saved)
        self.assertEqual(validate_app_definition({**DECLARATION, "schema_version": 2, "card_lifecycle": value})["card_lifecycle"], value)

    def test_no_implicit_delete_or_restore_or_missing_archive(self):
        for value in ({}, {"issue": {}}, {"issue": {"archive": {"mode": "external"}, "restore": "retain_external_state"}},
                      {"issue": {"archive": {"mode": "retain", "description": "History"}, "restore": "reopen"}}):
            with self.assertRaises(ValueError):
                validate_card_lifecycle(value)

    def test_card_interactions_are_declared_but_disabled_by_default(self):
        value = {"pull_request": [{"key": "merge_decision", "kind": "question", "description": "Choose a merge outcome.", "default_enabled": False, "choices": ["merge", "close", "hold"]}]}
        self.assertEqual(validate_card_interactions(value), value)
        with self.assertRaises(ValueError):
            validate_card_interactions({"pull_request": [{**value["pull_request"][0], "default_enabled": True}]})
