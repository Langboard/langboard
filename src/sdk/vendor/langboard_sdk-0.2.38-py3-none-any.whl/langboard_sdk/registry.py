"""Instance administrator registration for separately hosted apps."""

from __future__ import annotations

import re
from .client import MutationOutcomeUnknown
from .definition import validate_app_definition
from .management import _composition_key
from .rest import ApiTransport


class AppRegistry:
    def __init__(self, transport: ApiTransport):
        self._transport = transport

    async def list(self) -> list[dict]:
        result = await self._transport.request("GET", "/settings/apps/registry")
        if not isinstance(result.get("apps"), list):
            raise RuntimeError("App registry snapshot unavailable")
        return result["apps"]

    async def approve(self, declaration: dict, *, expected_revision: str | None = None) -> dict:
        declaration = validate_app_definition(declaration)
        if expected_revision is not None:
            self._revision(expected_revision)
        result = await self._transport.request("POST", "/settings/apps/registry", json={
            "declaration": declaration, "expected_revision": expected_revision,
        })
        return self._receipt(result, declaration["key"])

    async def disable(self, app_key: str, expected_revision: str) -> dict:
        if not re.fullmatch(r"[a-z][a-z0-9_-]{0,31}", app_key):
            raise ValueError("Invalid app key")
        self._revision(expected_revision)
        result = await self._transport.request("POST", f"/settings/apps/registry/{app_key}/disable", json={
            "expected_revision": expected_revision,
        })
        return self._receipt(result, app_key)

    async def compositions(self) -> dict:
        """Administrator discovery of approved groups and exact installed modules."""
        result = await self._transport.request("GET", "/settings/apps/compositions")
        if not isinstance(result.get("compositions"), list) or not isinstance(result.get("modules"), list):
            raise RuntimeError("App composition discovery unavailable")
        return result

    async def save_composition(self, key: str, name: str, description: str, module_keys: list[str],
                               *, expected_revision: str | None = None) -> dict:
        _composition_key(key)
        if (not isinstance(name, str) or not name.strip() or len(name) > 80
                or not isinstance(description, str) or not description.strip() or len(description) > 1000
                or not isinstance(module_keys, list) or not 1 <= len(module_keys) <= 16
                or any(not isinstance(k, str) for k in module_keys)):
            raise ValueError("A bounded reviewed composition is required")
        for module_key in module_keys:
            _composition_key(module_key)
        if len(set(module_keys)) != len(module_keys):
            raise ValueError("Composition members must be unique")
        if expected_revision is not None:
            self._revision(expected_revision)
        result = await self._transport.request("POST", "/settings/apps/compositions", json={
            "key": key, "name": name, "description": description,
            "module_keys": list(module_keys), "expected_revision": expected_revision,
        })
        group = result.get("composition")
        if (not isinstance(group, dict) or group.get("key") != key or group.get("module_keys") != module_keys
                or not isinstance(group.get("revision"), str) or not re.fullmatch(r"[0-9a-f]{64}", group["revision"])):
            raise MutationOutcomeUnknown("Composition receipt unavailable; read discovery before retrying")
        return group

    async def ungroup_composition(self, key: str, expected_revision: str) -> dict:
        """Remove presentation membership only; never withdraw module authority."""
        _composition_key(key)
        self._revision(expected_revision)
        result = await self._transport.request("POST", f"/settings/apps/compositions/{key}/ungroup",
                                               json={"expected_revision": expected_revision})
        if result.get("key") != key or result.get("ungrouped") is not True:
            raise MutationOutcomeUnknown("Ungroup receipt unavailable; read discovery before retrying")
        return result

    @staticmethod
    def _revision(value):
        if not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{64}", value):
            raise ValueError("A reviewed app revision is required")

    @staticmethod
    def _receipt(result, key):
        app = result.get("app")
        if (not isinstance(app, dict) or not isinstance(app.get("declaration"), dict)
                or app["declaration"].get("key") != key or type(app.get("is_enabled")) is not bool
                or type(app.get("generation")) is not int or app["generation"] < 1
                or not isinstance(app.get("revision"), str) or not re.fullmatch(r"[0-9a-f]{64}", app["revision"])):
            raise MutationOutcomeUnknown("App registration receipt unavailable; read registry before retrying")
        return app
