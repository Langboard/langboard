"""Optional app MCP declaration discovery; remote execution is not implied."""

from .execution import _uid
from .rest import ApiTransport


class AppMcp:
    def __init__(self, transport: ApiTransport):
        self.transport = transport

    async def catalog(self, board_uid: str, card_uid: str) -> dict:
        """Read card-bound declarations under separate MCP scope consent."""
        return await self.transport.request("GET", f"/apps/v1/boards/{_uid(board_uid)}/cards/{_uid(card_uid)}/mcp-tools")
