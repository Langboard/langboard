"""Opt-in app-card actions. Inbox signals never become card actions implicitly."""

import re
from copy import deepcopy


def validate_card_interactions(value):
    if not isinstance(value, dict) or len(value) > 32:
        raise ValueError("Card interactions must be a bounded map")
    result = {}
    for card_type, actions in value.items():
        if not isinstance(card_type, str) or not re.fullmatch(r"[a-z][a-z0-9_-]{0,63}", card_type):
            raise ValueError("Invalid card interaction type")
        if not isinstance(actions, list) or len(actions) > 16:
            raise ValueError("Card interactions must be bounded arrays")
        seen = set()
        normalized = []
        for action in actions:
            if not isinstance(action, dict) or set(action) != {"key", "kind", "description", "default_enabled", "choices"}:
                raise ValueError("Invalid card interaction declaration")
            key = action["key"]
            if not isinstance(key, str) or not re.fullmatch(r"[a-z][a-z0-9_-]{0,63}", key) or key in seen:
                raise ValueError("Invalid or duplicate card interaction key")
            if action["kind"] not in ("approval", "question", "action") or action["default_enabled"] is not False:
                raise ValueError("Card actions are opt-in and use a supported kind")
            if not isinstance(action["description"], str) or not action["description"].strip() or len(action["description"]) > 500:
                raise ValueError("Card interaction requires bounded description")
            choices = action["choices"]
            if not isinstance(choices, list) or not 1 <= len(choices) <= 16 or any(
                not isinstance(choice, str) or not re.fullmatch(r"[a-z][a-z0-9_-]{0,63}", choice) for choice in choices
            ) or len(set(choices)) != len(choices):
                raise ValueError("Card interaction choices must be stable unique IDs")
            seen.add(key)
            normalized.append(deepcopy(action))
        result[card_type] = normalized
    return result
