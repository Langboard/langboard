"""Board-owned App management through existing native REST contracts."""

import re
from dataclasses import asdict, dataclass
from typing import ClassVar, Literal, Protocol
from .client import MutationOutcomeUnknown
from .rest import ApiTransport
from .workflow import WorkflowStage


class ResourceSelection(Protocol):
    """Adapter-owned selection fields; the native server owns their validation.

    Implement this in an external app without adding its name to the SDK.
    The collection must match the connection manager's native API contract.
    """

    selection_collection: str

    def selection_fields(self) -> dict:
        ...


@dataclass(frozen=True)
class GlitchTipProject:
    selection_collection: ClassVar[str] = "projects"
    organization: str
    project_slug: str
    expected_resource_revision: int | None = None

    def selection_fields(self) -> dict:
        return {key: value for key, value in asdict(self).items() if value is not None}


@dataclass(frozen=True)
class DokployResource:
    selection_collection: ClassVar[str] = "selected"
    resource_type: Literal["project", "environment", "application", "compose"]
    external_id: str
    external_project_id: str | None = None
    environment_id: str | None = None
    expected_resource_revision: int | None = None

    def selection_fields(self) -> dict:
        return {key: value for key, value in asdict(self).items() if value is not None}


def _segment(value: str) -> str:
    if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", value):
        raise ValueError("A native identifier or app key is required")
    return value


def _composition_key(value):
    if not isinstance(value, str) or not re.fullmatch(r"[a-z][a-z0-9_-]{0,31}", value):
        raise ValueError("An exact composition or module key is required")
    return value


def _revision(value: str) -> str:
    if not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{64}", value):
        raise ValueError("A current native revision is required")
    return value


def _secret_reference(value: str) -> str:
    if not isinstance(value, str) or not re.fullmatch(r"secret://ref/[A-Za-z0-9]{1,11}", value):
        raise ValueError("Use a native secret reference, never a credential value")
    return value


class AppManager:
    """Inspect Apps and manage reviewed board bindings; never registers provider code."""

    def __init__(self, transport: ApiTransport, project_uid: str):
        self.transport = transport
        self.project_uid = _segment(project_uid)
        self.path = f"/board/{_segment(project_uid)}/settings/apps"

    async def catalog(self) -> dict:
        return await self.transport.request("GET", self.path)

    async def compositions(self) -> dict:
        """One board-authorized snapshot of presentation groups and module state."""
        result = await self.transport.request("GET", f"{self.path}/compositions")
        if not isinstance(result.get("compositions"), list) or not isinstance(result.get("apps"), list):
            raise RuntimeError("Board composition snapshot unavailable")
        return result

    async def disable_composition(self, key: str, expected_revision: str,
                                  binding_revisions: dict[str, str | None]) -> dict:
        """Explicit board withdrawal; exact current members, no automatic replay."""
        _composition_key(key)
        _revision(expected_revision)
        if not isinstance(binding_revisions, dict) or not 1 <= len(binding_revisions) <= 16:
            raise ValueError("All reviewed module binding revisions are required")
        for module_key, revision in binding_revisions.items():
            _composition_key(module_key)
            if revision is not None:
                _revision(revision)
        result = await self.transport.request("POST", f"{self.path}/compositions/{key}/disable", json={
            "expected_revision": expected_revision, "binding_revisions": dict(binding_revisions),
        })
        keys = result.get("module_keys")
        if (result.get("key") != key or result.get("disabled") is not True or not isinstance(keys, list)
                or any(not isinstance(k, str) for k in keys) or len(keys) != len(binding_revisions)
                or set(keys) != set(binding_revisions)):
            raise MutationOutcomeUnknown("Group withdrawal receipt unavailable; read snapshot before retrying")
        return result

    async def set_archive_sync(self, app_key: str, expected_revision: str, card_types: list[str]) -> dict:
        """Explicit user-authorized per-type opt-in. Empty types revoke; no provider action here."""
        if (not isinstance(card_types, list) or len(card_types) > 64
                or any(not isinstance(value, str) for value in card_types)
                or len(card_types) != len(set(card_types))):
            raise ValueError("Archive types must be a bounded unique list")
        return await self.transport.request("PUT", f"/board/{self.project_uid}/apps/{_segment(app_key)}/archive-sync",
                                            json={"expected_revision": _revision(expected_revision), "card_types": list(card_types)})

    async def prepare_consent(self, app_key: str, app_revision: str) -> dict:
        """Prepare a disabled binding; grants and workflow activation remain separate."""
        return await self.transport.request("POST", f"{self.path}/{_segment(app_key)}/consent",
            json={"app_revision": _revision(app_revision)})

    async def set_consent(self, app_key: str, app_revision: str, binding_uid: str,
                          expected_revision: str, capabilities: list[str]) -> dict:
        """Explicitly replace board grants; an empty list withdraws consent."""
        if (not isinstance(capabilities, list) or len(capabilities) > 32
                or any(not isinstance(value, str) or not re.fullmatch(r"[a-z][a-z0-9_.-]{0,63}", value)
                       for value in capabilities)
                or len(capabilities) != len(set(capabilities))):
            raise ValueError("Consent capabilities must be a bounded unique list")
        return await self.transport.request("PUT", f"{self.path}/{_segment(app_key)}/consent", json={
            "app_revision": _revision(app_revision), "binding_uid": _segment(binding_uid),
            "expected_revision": _revision(expected_revision), "capabilities": list(capabilities),
        })

    async def set_panel_consent(
        self, app_key: str, app_revision: str, *, enabled: bool, read_signals: bool = False,
        binding_uid: str | None = None, expected_revision: str | None = None,
    ) -> dict:
        """Reviewed rendering and optional signal reads; no mutation authority."""
        if type(enabled) is not bool or type(read_signals) is not bool:
            raise ValueError("Panel consent must be explicit")
        _revision(app_revision)
        if expected_revision is not None:
            _revision(expected_revision)
        if (binding_uid is None) != (expected_revision is None):
            raise ValueError("A binding UID and revision must be supplied together")
        return await self.transport.request("PUT", f"{self.path}/{_segment(app_key)}/panel", json={
            "app_revision": app_revision, "enabled": enabled, "read_signals": read_signals,
            "binding_uid": None if binding_uid is None else _segment(binding_uid),
            "expected_revision": expected_revision,
        })

    async def panel(self, app_key: str) -> dict:
        return await self.transport.request("GET", f"/board/{self.project_uid}/apps/{_segment(app_key)}/panel")

    async def workflow(self, app_key: str) -> dict:
        return await self.transport.request("GET", f"{self.path}/{_segment(app_key)}/workflow")

    async def prepare_workflow(self, app_key: str) -> dict:
        return await self.transport.request("POST", f"{self.path}/{_segment(app_key)}/workflow")

    async def save_workflow(
        self,
        app_key: str,
        binding_uid: str,
        expected_revision: str,
        mapping: dict[WorkflowStage, str] | None,
        *,
        enable_transitions: bool = False,
    ) -> dict:
        if type(enable_transitions) is not bool:
            raise ValueError("Transition enablement must be explicit")
        values = (
            None if mapping is None else {WorkflowStage(stage).value: _segment(uid) for stage, uid in mapping.items()}
        )
        return await self.transport.request(
            "PUT",
            f"{self.path}/{_segment(app_key)}/workflow",
            json={
                "binding_uid": _segment(binding_uid),
                "expected_revision": _revision(expected_revision),
                "workflow_mapping": values,
                "enable_transitions": enable_transitions,
            },
        )

    async def disable(self, app_key: str, binding_uid: str, expected_revision: str) -> dict:
        return await self.transport.request(
            "POST",
            f"{self.path}/{_segment(app_key)}/disable",
            json={
                "binding_uid": _segment(binding_uid),
                "expected_revision": _revision(expected_revision),
            },
        )

    def connections(
        self, app_key: str, *, selection_collection: str
    ) -> "ConnectionManager":
        return ConnectionManager(self.transport, f"{self.path}/{_segment(app_key)}", selection_collection)


class ConnectionManager:
    """Native instance onboarding for adapters exposing connection/selection endpoints.

    GlitchTip uses projects; Dokploy uses selected. GitHub's installation OAuth
    and repository delta protocol are different and are not implemented here.
    Selection fields follow the adapter's server schema, not a new SDK policy.
    """

    def __init__(self, transport: ApiTransport, path: str, selection_collection: str):
        self.transport, self.path, self.collection = transport, path, _segment(selection_collection)

    async def list(self, *, after: str | None = None) -> dict:
        return await self.transport.request(
            "GET", f"{self.path}/connections", params={"after": after} if after else None
        )

    async def request_secret_input(self) -> dict:
        return await self.transport.request("POST", f"{self.path}/secret-input")

    async def secret_input_status(self, input_uid: str) -> dict:
        return await self.transport.request("GET", f"{self.path}/secret-input/{_segment(input_uid)}")

    async def create(self, instance_url: str, credential_reference: str) -> dict:
        return await self.transport.request(
            "POST",
            f"{self.path}/connections",
            json={
                "instance_url": instance_url,
                "credential_reference": _secret_reference(credential_reference),
            },
        )

    async def discover(self, connection_uid: str, **filters: str) -> dict:
        return await self.transport.request(
            "GET", f"{self.path}/connections/{_segment(connection_uid)}/resources", params=filters or None
        )

    async def selected(self, connection_uid: str, *, after: str | None = None) -> dict:
        return await self.transport.request(
            "GET",
            f"{self.path}/connections/{_segment(connection_uid)}/{self.collection}",
            params={"after": after} if after else None,
        )

    async def select(
        self, connection_uid: str, expected_revision: str, selection: ResourceSelection
    ) -> dict:
        if getattr(selection, "selection_collection", None) != self.collection:
            raise ValueError("Selection must match the native adapter contract")
        fields = selection.selection_fields()
        if not isinstance(fields, dict) or any(not isinstance(key, str) for key in fields):
            raise ValueError("Selection fields must be a native JSON object")
        if "expected_revision" in fields:
            raise ValueError("Selection fields must not override the connection revision")
        return await self.transport.request(
            "POST",
            f"{self.path}/connections/{_segment(connection_uid)}/{self.collection}",
            json={**fields, "expected_revision": _revision(expected_revision)},
        )

    async def remove(self, connection_uid: str, resource_uid: str, expected_revision: int) -> dict:
        if type(expected_revision) is not int or expected_revision < 0:
            raise ValueError("A current resource access revision is required")
        return await self.transport.request(
            "POST",
            f"{self.path}/connections/{_segment(connection_uid)}/{self.collection}/{_segment(resource_uid)}/remove",
            json={"expected_revision": expected_revision},
        )

    async def disconnect(self, connection_uid: str, expected_revision: str) -> dict:
        return await self.transport.request(
            "POST",
            f"{self.path}/connections/{_segment(connection_uid)}/disconnect",
            json={"expected_revision": _revision(expected_revision)},
        )
