import unittest
from .interactions import validate_card_interaction

BASE = {
    "schema_version": 1,
    "kind": "question",
    "app_request_key": "deploy-choice",
    "prompt": {"en": "Choose", "ko": "선택"},
    "questions": [
        {
            "id": "action",
            "prompt": {"en": "Action"},
            "type": "single_choice",
            "choices": [
                {"id": "review", "label": {"en": "Review"}},
                {"id": "retry", "label": {"en": "Retry"}},
            ],
        }
    ],
    "presentation": {"type": "choice_card"},
    "outcomes": {"review": {"workflow_stage": "review"}},
    "expires_at": "2026-10-12T00:00:00+00:00",
}


class InteractionTests(unittest.TestCase):
    def test_valid_and_non_mutating(self):
        item = validate_card_interaction(BASE)
        self.assertEqual(item["questions"][0]["choices"][0]["id"], "review")
        self.assertEqual(BASE["presentation"]["type"], "choice_card")

    def test_approval_requires_explicit_choices(self):
        item = {
            **BASE,
            "kind": "approval",
            "outcomes": {},
            "questions": [
                {
                    **BASE["questions"][0],
                    "choices": [
                        {"id": "approve", "label": {"en": "Approve"}},
                        {"id": "reject", "label": {"en": "Reject"}},
                    ],
                }
            ],
        }
        self.assertEqual(validate_card_interaction(item)["kind"], "approval")

    def test_reaction_requires_current_comment_mapping(self):
        item = {
            **BASE,
            "presentation": {
                "type": "comment_reaction",
                "comment_uid": "A" * 11,
                "reactions": {"thumbs-up": "review", "thumbs-down": "retry"},
            },
        }
        self.assertEqual(
            validate_card_interaction(item)["presentation"]["type"], "comment_reaction"
        )

    def test_rejects_label_as_identity_and_expired_missing_timezone(self):
        item = {
            **BASE,
            "questions": [
                {
                    **BASE["questions"][0],
                    "choices": [{"id": "Review", "label": {"en": "Review"}}],
                }
            ],
        }
        with self.assertRaises(ValueError):
            validate_card_interaction(item)
        with self.assertRaises(ValueError):
            validate_card_interaction({**BASE, "expires_at": "2026-10-12T00:00:00"})

    def test_rejects_unknown_stage_and_reaction(self):
        with self.assertRaises(ValueError):
            validate_card_interaction(
                {**BASE, "outcomes": {"review": {"workflow_stage": "unknown"}}}
            )
        with self.assertRaises(ValueError):
            validate_card_interaction(
                {
                    **BASE,
                    "presentation": {
                        "type": "comment_reaction",
                        "comment_uid": "A" * 11,
                        "reactions": {"rocket": "review"},
                    },
                }
            )


if __name__ == "__main__":
    unittest.main()
