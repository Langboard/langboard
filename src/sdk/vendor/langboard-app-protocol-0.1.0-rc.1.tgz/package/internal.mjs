export const PANEL_LEGACY_OPERATIONS = Object.freeze(["signals.list","resources.list","interactions.list","interactions.open","runtimes.open"]);
export const PANEL_PROTOCOL_VERSION = 1;
export const PANEL_OPERATIONS = Object.freeze(["signals.list","resources.list","resources.open","interactions.list","interactions.open","runtimes.open"]);
const encoder = new TextEncoder();
export const MAX_STATE_BYTES = 16 * 1024;
export const MAX_RESPONSE_BYTES = 128 * 1024;
export const READY_TIMEOUT_MS = 10_000;
export const MAX_REQUESTS = 2;
export const REQUEST_ERRORS = ["Invalid panel request", "Unsupported panel operation", "Panel requests unavailable", "Too many panel requests", "Panel request failed", "Panel request timeout"];

export const requestId = (id) => Number.isSafeInteger(id) && id > 0;
export const onlyFields = (value, fields) => Object.keys(value).length === fields.length && fields.every((field) => Object.hasOwn(value, field));

// Validate before serialization: JSON.stringify alone silently drops unsafe values.
export function snapshot(value, maxBytes = MAX_STATE_BYTES) {
    if (!value || typeof value !== "object" || Array.isArray(value)) {
        throw new TypeError("Panel state must be a JSON object");
    }
    let nodes = 0;
    let contentBytes = 0;
    const countBytes = (text) => {
        contentBytes += encoder.encode(text).byteLength;
        if (contentBytes > maxBytes) throw new RangeError(`Panel state exceeds ${maxBytes / 1024} KiB`);
    };
    const ancestors = new Set();
    function visit(item, depth) {
        if (++nodes > MAX_STATE_BYTES || depth > 64) throw new RangeError("Panel state is too complex");
        if (item === null || typeof item === "boolean") return;
        if (typeof item === "string") {
            countBytes(item);
            return;
        }
        if (typeof item === "number" && Number.isFinite(item)) return;
        if (typeof item !== "object") throw new TypeError("Panel state must contain only JSON values");
        const proto = Object.getPrototypeOf(item);
        if (proto !== Object.prototype && proto !== null && !(Array.isArray(item) && proto === Array.prototype)) {
            throw new TypeError("Panel state has an unsupported prototype");
        }
        if (ancestors.has(item)) throw new TypeError("Panel state must not contain cycles");
        if (Array.isArray(item) && item.length > MAX_STATE_BYTES) throw new RangeError("Panel array is too large");
        if (Array.isArray(item) && Object.keys(item).length !== item.length) throw new TypeError("Panel arrays must not contain holes");
        ancestors.add(item);
        for (const key of Reflect.ownKeys(item)) {
            if (Array.isArray(item) && key === "length") continue;
            const property = Object.getOwnPropertyDescriptor(item, key);
            if (typeof key !== "string" || !property.enumerable || !("value" in property) ||
                key === "__proto__" || key === "constructor" || key === "prototype") {
                throw new TypeError("Panel state has an unsupported property");
            }
            countBytes(key);
            if (Array.isArray(item) && !/^(0|[1-9]\d*)$/.test(key)) throw new TypeError("Panel arrays must contain only indices");
            visit(property.value, depth + 1);
        }
        ancestors.delete(item);
    }
    visit(value, 0);
    const json = JSON.stringify(value);
    const bytes = encoder.encode(json).byteLength;
    if (bytes > maxBytes) throw new RangeError(`Panel state exceeds ${maxBytes / 1024} KiB`);
    return { json, bytes, value: JSON.parse(json) };
}

export function panelContext(context) {
    const result = {};
    for (const key of ["project_uid", "app_key", "app_version", "language"]) {
        if (typeof context?.[key] !== "string" || !context[key] || context[key].length > 1024) {
            throw new TypeError(`Invalid panel context: ${key}`);
        }
        result[key] = context[key];
    }
    return result;
}

// Matches the existing Langboard main.css semantic variables. No arbitrary CSS authority.
export const PANEL_DESIGN_TOKENS = Object.freeze([
    "--background", "--foreground", "--card", "--card-foreground", "--popover", "--popover-foreground",
    "--primary", "--primary-foreground", "--secondary", "--secondary-foreground", "--muted", "--muted-foreground",
    "--accent", "--accent-foreground", "--destructive", "--destructive-foreground", "--warning", "--warning-foreground",
    "--warning-border", "--border", "--input", "--ring", "--radius", "--chart-1", "--chart-2", "--chart-3",
    "--chart-4", "--chart-5", "--brand", "--highlight",
]);

export function panelDesign(input, expectedOrigin, allowResources = true) {
    const design = snapshot(input).value;
    if (design.mode !== "light" && design.mode !== "dark") throw new TypeError("Invalid panel design mode");
    if (Object.keys(design).some((key) => !["mode", "tokens", "resources"].includes(key))) throw new TypeError("Invalid design field");
    const tokens = snapshot(design.tokens).value;
    for (const [key, value] of Object.entries(tokens)) {
        if (!PANEL_DESIGN_TOKENS.includes(key) || typeof value !== "string" || value.length > 64) {
            throw new TypeError("Invalid panel design token");
        }
        if (key === "--radius") {
            if (!/^(?:\d+(?:\.\d+)?|\.\d+)(?:px|rem)$/.test(value) || parseFloat(value) > 64) {
                throw new TypeError("Invalid panel radius");
            }
        } else {
            const match = /^(\d+(?:\.\d+)?) (\d+(?:\.\d+)?)% (\d+(?:\.\d+)?)%$/.exec(value);
            if (!match || +match[1] > 360 || +match[2] > 100 || +match[3] > 100) {
                throw new TypeError("Invalid panel color channels");
            }
        }
    }
    const result = { mode: design.mode, tokens };
    if (design.resources !== undefined) {
        if (!allowResources) throw new TypeError("Design updates cannot change resources");
        const resources = snapshot(design.resources).value;
        if (Object.keys(resources).length !== 2) throw new TypeError("Invalid design resources");
        result.resources = {};
        for (const key of ["module_url", "css_url"]) {
            if (typeof resources[key] !== "string" || resources[key].length > 2048) throw new TypeError("Invalid design resource URL");
            const url = new URL(resources[key]);
            const local = ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname);
            if (url.username || url.password || url.hash || (url.protocol !== "https:" && !(url.protocol === "http:" && local)) ||
                (expectedOrigin && url.origin !== expectedOrigin)) throw new TypeError("Untrusted design resource URL");
            result.resources[key] = url.href;
        }
    }
    return result;
}


// Additive bootstrap metadata is descriptive, never an authorization grant.
export function advertisedOperations(value) {
    if (!Array.isArray(value) || value.length > 64 || value.some(operation =>
        typeof operation !== "string" || !/^[a-z][a-z0-9_.-]{0,63}$/.test(operation)) ||
        new Set(value).size !== value.length) throw new TypeError("Invalid supported operations");
    return Object.freeze([...value]);
}
