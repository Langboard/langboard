"""Native notification destinations and receipts under caller-owned authentication.

User consent and app attestation use separate authenticated transports. These
clients never obtain credentials, infer identity, grant access, or retry calls.
Host support and explicit user approval are required before provider delivery.
"""

import re
from typing import Literal, get_args

from .management import _positive, _request_id, _revision, _segment
from .rest import ApiTransport
from .resources import _uid

ReceiptStatus = Literal["adapter_accepted", "confirmed", "unknown", "rejected"]


def _text(value, maximum, field):
    if not isinstance(value, str) or not value.strip() or len(value) > maximum:
        raise ValueError(f"Invalid notification {field}")
    return value


def _fence(event_revision, subscription_generation, destination_revision):
    return {
        "event_revision": _positive(event_revision),
        "subscription_generation": _positive(subscription_generation),
        "destination_revision": _positive(destination_revision),
    }


class NotificationDestinations:
    """User-authenticated management, separate from app credentials and delivery."""

    def __init__(self, transport: ApiTransport):
        self.transport = transport

    async def onboarding(self, connection_uid: str) -> dict:
        """Read an explicitly declared browser entry; this grants no consent."""
        return await self.transport.request(
            "GET", f"/settings/apps/connections/{_segment(connection_uid)}/notification-onboarding",
        )

    async def configure_scope(self, subscription_uid: str, *, expected_generation: int,
                              event_kinds: list[str], project_uids: list[str]) -> dict:
        """Explicitly configure a user's subscription; never opt in implicitly."""
        supported = {"test", "card_activity", "card_deadline"}
        if (not isinstance(event_kinds, list) or not event_kinds or len(event_kinds) > 3
                or any(not isinstance(kind, str) or kind not in supported for kind in event_kinds)
                or len(set(event_kinds)) != len(event_kinds)
                or not isinstance(project_uids, list) or len(project_uids) > 50):
            raise ValueError("Invalid notification subscription scope")
        for uid in project_uids:
            _uid(uid)
        if len(set(project_uids)) != len(project_uids) or ("card_deadline" in event_kinds and not project_uids):
            raise ValueError("Invalid notification project scope")
        return await self.transport.request(
            "POST", f"/settings/apps/notification-subscriptions/{_segment(subscription_uid)}/scope",
            json={"expected_generation": _positive(expected_generation),
                  "event_kinds": event_kinds, "project_uids": project_uids},
        )

    async def service_template(self, connection_uid: str) -> dict:
        """Read the approved service template; this grants no custody consent."""
        return await self.transport.request(
            "GET", f"/settings/apps/connections/{_segment(connection_uid)}/service-template",
        )

    async def prepare_service_destination(
        self, connection_uid: str, *, expected_template_revision: int,
        expected_destination_revision: int | None = None,
    ) -> dict:
        """Pin the host's approved target without choosing a URL or secret."""
        return await self.transport.request(
            "POST", f"/settings/apps/connections/{_segment(connection_uid)}/service-destination",
            json={"expected_template_revision": _positive(expected_template_revision),
                  "expected_destination_revision": None if expected_destination_revision is None
                  else _positive(expected_destination_revision)},
        )

    async def create_challenge(
        self, connection_uid: str, *, request_id: str, expected_connection_revision: str,
    ) -> dict:
        return await self.transport.request(
            "POST", f"/settings/apps/connections/{_segment(connection_uid)}/notification-destination-challenges",
            json={"request_id": _request_id(request_id),
                  "expected_connection_revision": _revision(expected_connection_revision), "kind": "personal"},
        )

    async def challenge(self, challenge_uid: str) -> dict:
        return await self.transport.request(
            "GET", f"/settings/apps/notification-destination-challenges/{_segment(challenge_uid)}",
        )

    async def approve(self, challenge_uid: str, *, expected_revision: int, proof_uid: str) -> dict:
        """Call only after the initiating user reviews and approves the proof."""
        return await self.transport.request(
            "POST", f"/settings/apps/notification-destination-challenges/{_segment(challenge_uid)}/approve",
            json={"expected_revision": _positive(expected_revision), "proof_uid": _segment(proof_uid)},
        )

    async def cancel(self, challenge_uid: str, *, expected_revision: int) -> dict:
        return await self.transport.request(
            "POST", f"/settings/apps/notification-destination-challenges/{_segment(challenge_uid)}/cancel",
            json={"expected_revision": _positive(expected_revision)},
        )

    async def destination(self, destination_uid: str) -> dict:
        return await self.transport.request(
            "GET", f"/settings/apps/notification-destinations/{_segment(destination_uid)}",
        )

    async def revoke(self, destination_uid: str, *, expected_revision: int) -> dict:
        return await self.transport.request(
            "POST", f"/settings/apps/notification-destinations/{_segment(destination_uid)}/revoke",
            json={"expected_revision": _positive(expected_revision)},
        )


class AppNotificationDeliveries:
    """Use an exact app-connection credential transport, never a user's bearer.

    Attest only identity and destinations derived from the app's verified login.
    A proof submission does not approve a destination or authorize a send.
    """

    def __init__(self, transport: ApiTransport):
        self.transport = transport

    async def custody_status(self) -> dict:
        """Read only this staged/current credential's native custody metadata.

        Prepared is not usable. Preserve the staged candidate on unavailable
        responses; activation requires the host's current usable decision.
        This request never substitutes general app identity authentication.
        """
        return await self.transport.request("GET", "/apps/v1/credential-custody/status")

    async def renew(self, request_id: str) -> dict:
        """Request one native renewal with the current credential transport.

        The host owns eligibility, callback, expiry and revocation. Retain the
        current finite credential until the staged replacement is confirmed
        usable; a callback or HTTP success alone does not activate it.
        """
        return await self.transport.request(
            "POST", "/apps/v1/credential-custody/renew", json={"request_id": _request_id(request_id)},
        )

    async def submit_proof(
        self, challenge_uid: str, *, challenge_token: str, request_id: str,
        issuer: str, subject: str, external_id: str, display_name: str,
    ) -> dict:
        if not isinstance(challenge_token, str) or not re.fullmatch(r"[A-Za-z0-9_-]{43}", challenge_token):
            raise ValueError("A native destination challenge token is required")
        return await self.transport.request(
            "POST", "/apps/v1/notification-destination-proofs",
            json={
                "challenge_uid": _segment(challenge_uid), "challenge_token": challenge_token,
                "request_id": _request_id(request_id),
                "external_identity": {"issuer": _text(issuer, 500, "issuer"),
                                      "subject": _text(subject, 255, "subject")},
                "destination": {"kind": "personal", "external_id": _text(external_id, 200, "external identity"),
                                "display_name": _text(display_name, 80, "display name")},
            },
        )

    async def authorize(
        self, event_uid: str, *, event_revision: int, subscription_generation: int,
        destination_revision: int,
    ) -> dict:
        """Recheck immediately before provider I/O; do not cache this decision."""
        return await self.transport.request(
            "POST", f"/apps/v1/notification-events/{_segment(event_uid)}/delivery-authorization",
            json=_fence(event_revision, subscription_generation, destination_revision),
        )

    async def receipt(
        self, event_uid: str, *, request_id: str, event_revision: int,
        subscription_generation: int, destination_revision: int, status: ReceiptStatus,
        expected_revision: int | None = None, reconciled: bool = False,
        provider_message_id: str | None = None, reason_code: str | None = None,
    ) -> dict:
        """Report retained evidence; unknown outcomes require explicit reconciliation.

        HTTP success is not provider confirmation. The native host validates
        receipt transitions, current authority and conflicting or stale evidence.
        This method never calls the provider or resends an unknown notification.
        """
        if status not in get_args(ReceiptStatus) or type(reconciled) is not bool:
            raise ValueError("Invalid notification receipt fields")
        body = {
            **_fence(event_revision, subscription_generation, destination_revision),
            "request_id": _request_id(request_id), "status": status,
            "expected_revision": None if expected_revision is None else _positive(expected_revision),
            "reconciled": reconciled,
        }
        if provider_message_id is not None:
            body["provider_message_id"] = _text(provider_message_id, 200, "provider message identity")
        if reason_code is not None:
            body["reason_code"] = _text(reason_code, 64, "reason code")
        return await self.transport.request(
            "POST", f"/apps/v1/notification-events/{_segment(event_uid)}/receipts", json=body,
        )
